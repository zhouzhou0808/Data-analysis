
library(ggVennDiagram)
library(VennDiagram)
library(tidyverse)
library(readxl)
otu_tax_combined <- read.csv("../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
Genus_df <- species_B[, "Genus", drop = FALSE]
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])

samples_pre <- row.names(Gro_raw[Gro_raw$PERIOD == "EWP", ])  
samples_post <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP", ]) 
otu_pre <- otu_no_tax[, samples_pre, drop = FALSE]
otu_post <- otu_no_tax[, samples_post, drop = FALSE]
pre_otus        <- rownames(otu_pre)[apply(otu_pre, 1, function(x) any(x > 0))]
post_otus        <- rownames(otu_post)[apply(otu_post, 1, function(x) any(x > 0))]
#pre_otus        <- rownames(ZBJ.otus_pre_w)[apply(ZBJ.otus_pre_w, 1, function(x) any(x > 0))]
#post_otus        <- rownames(ZBJ.otus_post_w)[apply(ZBJ.otus_post_w, 1, function(x) any(x > 0))]


venn_data21 <- list(
  pre  = pre_otus,
  post = post_otus
)
venn_data22 <- list(
  pre_H = pre_H_otus,
  post_H = post_H_otus
)
venn_data23 <- list(
  pre_W = pre_W_otus,
  post_W = post_W_otus
)
venn_data24 <- list(
  pre_D = pre_D_otus,
  post_D = post_D_otus
)
venn_data25 <- list(
  pre_F = pre_F_otus,
  post_F = post_F_otus
)


venn_data3 <- list(
  post_F = post_F_otus,
  post_H = post_H_otus,
  post_W = post_W_otus
)
venn_data4 <- list(
  pre_F = pre_F_otus,
  pre_H = pre_H_otus,
  pre_W = pre_W_otus,
  pre_D = pre_D_otus
)
venn_data4 <- list(
  post_F = post_F_otus,
  post_H = post_H_otus,
  post_W = post_W_otus,
  post_D = post_D_otus
)

g4 <- venn.diagram(venn_data4,
                  filename = NULL,
                  category.names = c("A","B","C","D"),
                  print.mode = c('raw','percent'),
                  main = "Four Group",
                  main.fontfamily = "serif",
                  main.pos = c(0.5, 1.05),
                  main.cex = 1,
                  scaled = TRUE,
                  fill =c("#FDCABF",
                          "#CBDDDB",
                          "#E0BBD0",
                          "#EFC99B"))
g3 <- venn.diagram(venn_data3,
                   filename = NULL,
                   category.names = c("A","B","C"),
                   print.mode = c('raw','percent'),
                   main = "Two Group",
                   main.fontfamily = "serif",
                   main.pos = c(0.5, 1.05),
                   main.cex = 2,
                   scaled = TRUE,
                   fill =c("#007575","#FFAA00"))
g2 <- venn.diagram(venn_data25,
                  filename = NULL,
                  category.names = c("pre","post"),
                  print.mode = c('raw','percent'),
                  main = "Two Group",
                  main.fontfamily = "serif",
                  main.pos = c(0.5, 1.05),
                  main.cex = 2,
                  scaled = TRUE,
                  fill =c("#EFC99B","#CBDDDB"))

g2
g3
g4
###############################################NICHE BREADTH##################
library(vegan)
library(spaa)
library(ggpubr)
library(dplyr)
library(fmsb)
Genus_otu_pre <- cbind(otu_pre, Genus_df)
Genus_otu_pre <- Genus_otu_pre %>%
  mutate(Genus = trimws(Genus)) %>%
  group_by(Genus) %>%
  summarise(
    across(where(is.numeric), \(x) sum(x, na.rm = TRUE)),
    .groups = "drop"
  )
Genus_otu_post <- cbind(otu_post, Genus_df)
Genus_otu_post <- Genus_otu_post %>%
  mutate(Genus = trimws(Genus)) %>%
  group_by(Genus) %>%
  summarise(
    across(where(is.numeric), \(x) sum(x, na.rm = TRUE)),
    .groups = "drop"
  )

Genus_otu_post <- column_to_rownames(Genus_otu_post, var = "Genus")
Genus_otu_pre <- column_to_rownames(Genus_otu_pre, var = "Genus")
samples_pre <- row.names(Gro_raw[Gro_raw$PERIOD == "EWP", ])  , Gro_raw$TYPE), ])
samples_post <- row.names(Gro_raw[Gro_raw$PERIOD == "LEP", ]) 


Genus_otu_pre1 <- Genus_otu_pre[,samples_pre]
Genus_otu_post1 <- Genus_otu_post[,samples_post]



N_otu_pre <- data.frame(t(otu_pre))
N_otu_post <- data.frame(t(otu_post))


N_otu_pre <- N_otu_pre[, colSums(N_otu_pre) > 0]
N_otu_post <- N_otu_post[,colSums(N_otu_post) > 0 ]
niche_edith_pre <- niche.width(N_otu_pre,method = "levins")
niche_edith_post <- niche.width(N_otu_post,method = "levins")
niche_edith_pre<-data.frame(t(niche_edith_pre))
niche_edith_post<-data.frame(t(niche_edith_post))
niche_edith_pre$Genus<-rownames(niche_edith_pre)
niche_edith_post$Genus<-rownames(niche_edith_post)
colnames(niche_edith_pre)[1] <- "niche_widch"
colnames(niche_edith_post)[1] <- "niche_widch"
#ll_data <- cbind(niche_edith_pre, niche_edith_post)
#write.csv(ll_data,
#          file = "ll_niche_data.csv",
#          row.names = FALSE)
niche_edith_pre$Group<-"pre"
mean(niche_edith_pre$niche_widch)
mean(niche_edith_post$niche_widch)
niche_edith_post$Group<-"post"
all_data <- rbind(niche_edith_pre,niche_edith_post)
kruskal.test(niche_widch ~ Group, data = all_data)
#生态位重叠
#over_pre <- niche.overlap(N_otu_pre,method="pianka")
#over_post <- niche.overlap(N_otu_post,method="pianka")
#over_pre
#over_post
#生态位重叠指数
#nob_pre <- niche.overlap.boot(N_otu_pre, method = "pianka")
#nob_post <- niche.overlap.boot(N_otu_post, method = "pianka")
#library(dplyr)
#library(fmsb)

# 2. 取 pre Top10
pre_top_all <- all_data %>%
  filter(Group == "pre", !is.na(niche_widch)) %>%
  arrange(desc(niche_widch)) %>%
  slice(1:13) %>%             
  filter(Genus != "g__norank") %>%  
  slice(1:10)                 

top_genus <- pre_top_all$Genus  
top_genus

# ======================
# ======================
plot_data <- all_data %>%
  filter(Genus %in% top_genus, !is.na(niche_widch)) %>%
  select(Group, Genus, niche_widch)


# ======================
# ======================
plot_wide <- plot_data %>%
  pivot_wider(
    names_from = Genus,
    values_from = niche_widch,
    values_fill = 0
  )


# ======================
# ======================
radar_mat <- plot_wide %>%
  column_to_rownames("Group") %>%
  mutate(across(everything(), as.numeric)) 
radar_mat[is.na(radar_mat)] <- 0


# ======================
# ======================
max_val <- max(radar_mat, na.rm = TRUE) * 1.2
min_val <- 0

radar_final <- rbind(
  rep(max_val, ncol(radar_mat)),
  rep(min_val, ncol(radar_mat)),
  radar_mat
)


# ======================
# ======================
radarchart(
  radar_final,
  axistype = 0,
  pcol = c("#ffa396",
           "#bed2c5"),    
  plwd = 3,                          
  plty = c(1, 1),                   
  pfcol = scales::alpha(c("#FDCABF","#CBDDDB"), 0.3), 
  cglcol = "gray80",               
  cglty = 1,                         
  axislabcol = "black",               
  caxislabels = seq(min_val, round(max_val,2), length.out = 5),
  calcex = 0.8,
  vlcex = 0.9                        )

legend(
  "topright",
  legend = c("Pre", "Post"),
  bty = "n",
  col = c("#ffa396",
          "#bed2c5"),
  lwd = 3,
  cex = 1
)



set.seed(123)
plot_points <- all_data %>%
  group_by(Group) %>%
  slice_sample(n = 1000) %>%
  ungroup()

box_stat <- all_data %>%
  group_by(Group) %>%
  summarise(
    ymin = boxplot.stats(niche_widch)$stats[1],
    lower = boxplot.stats(niche_widch)$stats[2],
    middle = boxplot.stats(niche_widch)$stats[3],
    upper = boxplot.stats(niche_widch)$stats[4],
    ymax = boxplot.stats(niche_widch)$stats[5]
  )
g<-ggplot(all_data, aes(x = Group, y = niche_widch)) +

  geom_boxplot(
    fill = NA,
    color = "black",
    width = 0.7,
    outlier.shape = NA,
    coef = 0,
       whisker.linewidth = 0,
    staplewidth = 0
  ) +
   geom_segment(
    data = box_stat,
    aes(
      x = Group,
      xend = Group,
      y = upper,
      yend = ymax
    ),
    linetype = "dashed",
    linewidth = 0.5
  ) +
    geom_segment(
    data = box_stat,
    aes(
      x = Group,
      xend = Group,
      y = lower,
      yend = ymin
    ),
    linetype = "dashed",
    linewidth = 0.5
  ) +

  geom_segment(
    data = box_stat,
    aes(
      x = as.numeric(factor(Group)) - 0.1,
      xend = as.numeric(factor(Group)) + 0.1,
      y = ymax,
      yend = ymax
    ),
    linewidth = 0.6
  ) +

  geom_segment(
    data = box_stat,
    aes(
      x = as.numeric(factor(Group)) - 0.1,
      xend = as.numeric(factor(Group)) + 0.1,
      y = ymin,
      yend = ymin
    ),
    linewidth = 0.6
  ) +
  geom_jitter(
    data = plot_points,
    aes(color = Group),
    width = 0.18,
    shape = 16,
    size = 1.2,
    alpha = 0.9
  ) +
  scale_color_manual(values = c(
    "pre" = "#ffa396",
    "post" = "#bed2c5"
  )) +
  scale_x_discrete(expand = expansion(mult = c(0.5, 0.5)))+


  theme_bw() +
  theme(
    panel.grid = element_blank(),
    legend.position = "none"
  ) +
    labs(
    x = "Group",
    y = "Niche width (Levins index)"
  )+
  coord_cartesian(ylim = c(-10, 45))
g
ggsave(
   plot = g,
  width = 4,
  height = 6,
  dpi = 600
)
