#library(reticulate)
#exit
#reticulate::py_install(c("matplotlib", "pandas", "networkx"))
#reticulate::py_install("seaborn")


# -*- coding: utf-8 -*-
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import networkx as nx

from networkx.readwrite import json_graph
import json

import pandas

import copy
import random

# === LOAD NETWORKS ===
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import networkx as nx
import random
import seaborn as sns
from collections import Counter

# =====================

# =====================
post_W_f = nx.read_graphml("../post/W.f_mb_net.graphml")
pre_W_f = nx.read_graphml("../pre/W.f_mb_net.graphml")



F_f = nx.read_graphml("../F.f_mb_net.graphml")
H_f = nx.read_graphml("../H.f_mb_net.graphml")
W_f = nx.read_graphml("../W.f_mb_net.graphml")
D_f = nx.read_graphml("../D.f_mb_net.graphml")

netdict = {
    "F_f": F_f,
    "H_f": H_f,
    "W_f": W_f,
    "D_f": D_f
}


for net in netdict.keys():
    mapping = {node: data['name'] for node, data in netdict[net].nodes(data=True)}
    nx.relabel_nodes(netdict[net], mapping, copy=False)


# =====================
metadata_F_f  = pd.read_csv("../F.f_metadata_metadata.csv")
metadata_H_f  = pd.read_csv("../H.f_metadata_metadata.csv")
metadata_W_f  = pd.read_csv("../W.f_metadata_metadata.csv")
metadata_D_f  = pd.read_csv("../D.f_metadata_metadata.csv")

weights_F_f  = pd.read_csv("../edgeweights_F.f.csv")
weights_H_f  = pd.read_csv("../edgeweights_H.f.csv")
weights_W_f  = pd.read_csv("../edgeweights_W.f.csv")
weights_D_f  = pd.read_csv("../edgeweights_D.f.csv")


for df in [metadata_F_f, metadata_H_f, metadata_W_f, metadata_D_f,
           weights_F_f, weights_H_f, weights_W_f, weights_D_f]:
    df.rename(columns=lambda x: x.replace('.', '|'), inplace=True)


# =====================
def add_weights(net, weights):
    for _, row in weights.iterrows():
        v1, v2, w = row["v1"], row["v2"], row["edgeweight"]
        if net.has_edge(v1, v2):
            net[v1][v2]["weight"] = w
            net[v1][v2]["invWeight"] = 1 - w

add_weights(F_f, weights_F_f)
add_weights(H_f, weights_H_f)
add_weights(W_f, weights_W_f)
add_weights(D_f, weights_D_f)


# =====================
def filter_positive_edges(net):
    G_filtered = net.__class__()
    for n, attrs in net.nodes(data=True):
        G_filtered.add_node(n, **attrs)
    for u, v, data in net.edges(data=True):
        w = data.get("weight", None)
        if w is not None and w > 0:
            G_filtered.add_edge(u, v, **data)
    return G_filtered

F_f = filter_positive_edges(F_f)
H_f = filter_positive_edges(H_f)
W_f = filter_positive_edges(W_f)
D_f = filter_positive_edges(D_f)


# =====================
def get_connected_graph(net):
    components = list(nx.connected_components(net))
    largest_component = max(components, key=len)
    return net.subgraph(largest_component)

F_f = get_connected_graph(F_f)
H_f = get_connected_graph(H_f)
W_f = get_connected_graph(W_f)
D_f = get_connected_graph(D_f)


# =====================
def add_abundance(net, metadata):
    abundance_dict = pd.Series(metadata.Abundance.values, index=metadata.Label).to_dict()
    nx.set_node_attributes(net, abundance_dict, 'Abundance')

add_abundance(F_f, metadata_F_f)
add_abundance(H_f, metadata_H_f)
add_abundance(W_f, metadata_W_f)
add_abundance(D_f, metadata_D_f)

# =====================
=========
H_f_col = "#2a9d8f"
F_f_col = "#264653"
D_f_col = "#edafb8"
W_f_col = "#703d67"

colors = {
    "F_f": F_f_col,
    "H_f": H_f_col,
    "W_f": W_f_col,
    "D_f": D_f_col
}


# =====================
def calculate_critical_threshold(x_vals_fraction, lcc_sizes_normalized_fraction):
    if len(lcc_sizes_normalized_fraction) <= 1:
        return 0.0
    slopes = np.diff(lcc_sizes_normalized_fraction)
    if len(slopes) == 0:
        return 0.0
    critical_index = np.argmin(slopes)
    return x_vals_fraction[critical_index + 1]

def find_i50(x_vals_fraction, lcc_sizes_normalized_fraction):
    i50 = []
    for i,j in zip(x_vals_fraction, lcc_sizes_normalized_fraction):
        if j >= 0.5:
            i50.append(i)
    return i50[-1] if i50 else 0


# =====================
def attack_degree(g_original, n):
    g = g_original.copy()
    lcc_sizes = [len(max(nx.connected_components(g), key=len)) if g else 0]
    for _ in range(n):
        if not g.nodes():
            lcc_sizes.append(0)
            continue
        node = max(g.degree, key=lambda x: x[1])[0]
        g.remove_node(node)
        lcc = len(max(nx.connected_components(g), key=len)) if g else 0
        lcc_sizes.append(lcc)
    return np.array(lcc_sizes)

def attack_betweenness(g_original, n):
    g = g_original.copy()
    lcc_sizes = [len(max(nx.connected_components(g), key=len)) if g else 0]
    for _ in range(n):
        if not g.nodes():
            lcc_sizes.append(0)
            continue
        bc = nx.betweenness_centrality(g, weight="invWeight")
        node = max(bc, key=bc.get)
        g.remove_node(node)
        lcc = len(max(nx.connected_components(g), key=len)) if g else 0
        lcc_sizes.append(lcc)
    return np.array(lcc_sizes)

def attack_abundance(g_original, n):
    g = g_original.copy()
    lcc_sizes = [len(max(nx.connected_components(g), key=len)) if g else 0]
    for _ in range(n):
        if not g.nodes():
            lcc_sizes.append(0)
            continue
        nodes = [n for n in g.nodes() if 'Abundance' in g.nodes[n]]
        node = sorted(nodes, key=lambda x: g.nodes[x]['Abundance'])[-1]
        g.remove_node(node)
        lcc = len(max(nx.connected_components(g), key=len)) if g else 0
        lcc_sizes.append(lcc)
    return np.array(lcc_sizes)

def attack_inverse_abundance(g_original, n):
    g = g_original.copy()
    lcc_sizes = [len(max(nx.connected_components(g), key=len)) if g else 0]
    for _ in range(n):
        if not g.nodes():
            lcc_sizes.append(0)
            continue
        nodes = [n for n in g.nodes() if 'Abundance' in g.nodes[n]]
        node = sorted(nodes, key=lambda x: g.nodes[x]['Abundance'])[0]
        g.remove_node(node)
        lcc = len(max(nx.connected_components(g), key=len)) if g else 0
        lcc_sizes.append(lcc)
    return np.array(lcc_sizes)

# =====================

# =====================
def simulate_attack(g, attack_type):
    n = g.order()
    if attack_type == 'degree':
        lcc = attack_degree(g,n)
    elif attack_type == 'betweenness':
        lcc = attack_betweenness(g,n)
    elif attack_type == 'abundance':
        lcc = attack_abundance(g,n)
    elif attack_type == 'inverse_abundance':
        lcc = attack_inverse_abundance(g,n)
    else:
        raise ValueError()
    
    norm = lcc / lcc[0]
    x = np.arange(len(norm))/n
    fc = calculate_critical_threshold(x, norm)
    i50 = find_i50(x, norm)
    return {'x_values':x, 'y_values':norm, 'fc_value':fc, 'i50_value':i50}


F_f_deg = simulate_attack(F_f, 'degree')
H_f_deg = simulate_attack(H_f, 'degree')
W_f_deg = simulate_attack(W_f, 'degree')
D_f_deg = simulate_attack(D_f, 'degree')
print(F_f_deg)
F_f_bet = simulate_attack(F_f, 'betweenness')
H_f_bet = simulate_attack(H_f, 'betweenness')
W_f_bet = simulate_attack(W_f, 'betweenness')
D_f_bet = simulate_attack(D_f, 'betweenness')

F_f_abu = simulate_attack(F_f, 'abundance')
H_f_abu = simulate_attack(H_f, 'abundance')
W_f_abu = simulate_attack(W_f, 'abundance')
D_f_abu = simulate_attack(D_f, 'abundance')

F_f_ia = simulate_attack(F_f, 'inverse_abundance')
H_f_ia = simulate_attack(H_f, 'inverse_abundance')
W_f_ia = simulate_attack(W_f, 'inverse_abundance')
D_f_ia = simulate_attack(D_f, 'inverse_abundance')


degree_res = {"F_f":F_f_deg,"H_f":H_f_deg,"W_f":W_f_deg,"D_f":D_f_deg}
bet_res   = {"F_f":F_f_bet,"H_f":H_f_bet,"W_f":W_f_bet,"D_f":D_f_bet}
abu_res   = {"F_f":F_f_abu,"H_f":H_f_abu,"W_f":W_f_abu,"D_f":D_f_abu}
ia_res    = {"F_f":F_f_ia,"H_f":H_f_ia,"W_f":W_f_ia,"D_f":D_f_ia}

# =====================
# =====================
fig, (ax1, ax2) = plt.subplots(1,2,figsize=(8,3.25),dpi=300)
for name, res in degree_res.items():
    ax1.plot(res['x_values']*100, res['y_values']*100, color=colors[name],label=name,lw=2)
for name, res in bet_res.items():
    ax2.plot(res['x_values']*100, res['y_values']*100, color=colors[name],label=name,lw=2)
ax1.set_xlabel("% removed nodes")
ax1.set_ylabel("% LCC")
ax2.set_xlabel("% removed nodes")
ax1.legend()
ax2.legend()
plt.tight_layout()
plt.savefig("degree_betweenness.png",dpi=300,bbox_inches='tight')

# =====================
# =====================
fig, (ax1, ax2) = plt.subplots(1,2,figsize=(8,3.25),dpi=300)
for name, res in abu_res.items():
    ax1.plot(res['x_values']*100, res['y_values']*100, color=colors[name],label=name,lw=2)
for name, res in ia_res.items():
    ax2.plot(res['x_values']*100, res['y_values']*100, color=colors[name],label=name,lw=2)
ax1.set_xlabel("% removed nodes")
ax1.set_ylabel("% LCC")
ax2.set_xlabel("% removed nodes")
ax1.legend()
ax2.legend()
plt.tight_layout()
plt.savefig("abundance_attack.png",dpi=300,bbox_inches='tight')

# =====================
# =====================
def remove_random_node(g):
    lcc = []
    order = g.order()
    for _ in range(order):
        node = random.choice(list(g.nodes()))
        g.remove_node(node)
        lcc.append(len(max(nx.connected_components(g), key=len)) if g else 0)
    return lcc

random.seed(505)
nreps = 1000

F_rand = [remove_random_node(nx.Graph(F_f)) for _ in range(nreps)]
H_rand = [remove_random_node(nx.Graph(H_f)) for _ in range(nreps)]
W_rand = [remove_random_node(nx.Graph(W_f)) for _ in range(nreps)]
D_rand = [remove_random_node(nx.Graph(D_f)) for _ in range(nreps)]

F_mean = np.mean(F_rand,axis=0)/F_f.order()*100
H_mean = np.mean(H_rand,axis=0)/H_f.order()*100
W_mean = np.mean(W_rand,axis=0)/W_f.order()*100
D_mean = np.mean(D_rand,axis=0)/D_f.order()*100

F_sd = np.std(F_rand,axis=0)/F_f.order()*100
H_sd = np.std(H_rand,axis=0)/H_f.order()*100
W_sd = np.std(W_rand,axis=0)/W_f.order()*100
D_sd = np.std(D_rand,axis=0)/D_f.order()*100

xF = np.arange(len(F_mean))/F_f.order()*100
xH = np.arange(len(H_mean))/H_f.order()*100
xW = np.arange(len(W_mean))/W_f.order()*100
xD = np.arange(len(D_mean))/D_f.order()*100

# =====================

# =====================
fig, (ax1,ax2) = plt.subplots(1,2,figsize=(8,3.25),dpi=300)
ax1.plot(xF, F_mean, color=F_f_col, label="F_f",lw=2)
ax1.fill_between(xF, F_mean-F_sd, F_mean+F_sd, alpha=0.2, color=F_f_col)
ax1.plot(xH, H_mean, color=H_f_col, label="H_f",lw=2)
ax1.fill_between(xH, H_mean-H_sd, H_mean+H_sd, alpha=0.2, color=H_f_col)
ax1.plot(xW, W_mean, color=W_f_col, label="W_f",lw=2)
ax1.fill_between(xW, W_mean-W_sd, W_mean+W_sd, alpha=0.2, color=W_f_col)
ax1.plot(xD, D_mean, color=D_f_col, label="D_f",lw=2)
ax1.fill_between(xD, D_mean-D_sd, D_mean+D_sd, alpha=0.2, color=D_f_col)
ax1.set_xlabel("% removed nodes")
ax1.set_ylabel("% LCC")
ax1.legend()


nr50 = []
for reps in [F_rand, H_rand, W_rand, D_rand]:
    nr = []
    for r in reps:
        n = len(r)
        for idx, val in enumerate(r):
            if val/n <= 0.5:
                nr.append(idx/n*100)
                break
    nr50.append(nr)

df = pd.DataFrame({
    "F_f":nr50[0],
    "H_f":nr50[1],
    "W_f":nr50[2],
    "D_f":nr50[3]
})

sns.boxplot(data=df, ax=ax2, palette=colors, showfliers=False)
sns.stripplot(data=df, ax=ax2, palette=colors, size=2, jitter=0.1)
ax2.set_ylabel("NR50")
plt.tight_layout()
plt.savefig("random_attack.png",dpi=300,bbox_inches='tight')
plt.show()


# =====================

# random_nr50.csv
df_nr50 = pd.DataFrame({
    "F_f": nr50[0],
    "H_f": nr50[1],
    "W_f": nr50[2],
    "D_f": nr50[3]
})
df_nr50.to_csv("random_nr50.csv", index=False)


def get_fc(reps, original_order):
    fc_vals = []
    for r in reps:
        x = np.arange(len(r)) / original_order
        y = np.array(r) / r[0]
        slopes = np.diff(y)
        if len(slopes) == 0:
            fc = 0.0
        else:
            critical_index = np.argmin(slopes)
            fc = x[critical_index + 1]
        fc_vals.append(fc)
    return fc_vals

fc_F = get_fc(F_rand, F_f.order())
fc_H = get_fc(H_rand, H_f.order())
fc_W = get_fc(W_rand, W_f.order())
fc_D = get_fc(D_rand, D_f.order())

df_fc = pd.DataFrame({
    "F_f": fc_F,
    "H_f": fc_H,
    "W_f": fc_W,
    "D_f": fc_D
})
df_fc.to_csv("random_fc.csv", index=False)

print(random_nr50.csv  and  random_fc.csv")


