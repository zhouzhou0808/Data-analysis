

#BiocManager::install("WGCNA", force = T)
#install.packages("flashClust")
library(WGCNA)
library(flashClust)
#BiocManager::install(c("impute", "preprocessCore"))
#install.packages("WGCNA")
#install.packages("flashClust")
library(iterators)
library(dplyr)
library(writexl)
#install.packages("writexl")
library(tibble)
library(readxl)
otu_tax_combined <- read.csv("../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
Genus_df <- species_B[, "Genus", drop = FALSE]
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])
otus <-  otu_no_tax
#otus <- otus1[rowSums(otus1 > 0) >= ceiling(ncol(otus1) * 0.1), ]
otus_Genus <- cbind(otus, Genus_df)
genus_table <- otus_Genus %>%
  mutate(Genus = trimws(Genus)) %>%
  group_by(Genus) %>%
  summarise(
    across(where(is.numeric), \(x) sum(x, na.rm = TRUE)),
    .groups = "drop"
  )
genus_mat <- genus_table %>%
  mutate(
    Genus = trimws(Genus),
    total = rowSums(across(where(is.numeric)), na.rm = TRUE)
  ) %>%
  filter(!grepl("^g__norank", Genus)) %>%
  arrange(desc(total)) %>%
  select(-total) %>%
  column_to_rownames("Genus")
colnames(genus_mat)
genus_mat_NW <- genus_mat[, grepl("NW", colnames(genus_mat)), drop = FALSE]
genus_mat_NW <- genus_mat_NW [rowSums(genus_mat_NW > 0) >= ceiling(ncol(genus_mat_NW ) * 0.1), ]
drop_cols <- c("NW1-1", "NW1-2", "NW1-3", "NW2-1", "NW2-2", "NW2-3")
genus_mat_NW <- genus_mat_NW[, !colnames(genus_mat_NW) %in% drop_cols]
#genus_mat_NW_top500 <- genus_mat_NW[head(order(rowSums(genus_mat_NW), decreasing = TRUE), 500), ]

######################################
F_diff <- read.csv(
  "res_diff.csv", 
  row.names = 1, 
  check.names = FALSE,
  fileEncoding = "GBK"   )
F_diff <- F_diff[grepl("g__", rownames(F_diff)) & !grepl("\\|s__", rownames(F_diff)), ]
row.names(F_diff)
F_diff <- F_diff[F_diff$LDA > 3, ]
F_diff <- F_diff[!grepl("g__norank", rownames(F_diff)), ]
F_diff$ID <- sub(".*g__", "g__", rownames(F_diff))
F_diff_otu_G <- genus_mat[F_diff$ID,]
W_diff_otu_G <- F_diff_otu_G[, grepl("NW", colnames(F_diff_otu_G)), drop = FALSE]
drop_cols <- c("NW1-1", "NW1-2", "NW1-3", "NW2-1", "NW2-2", "NW2-3")
W_diff_otu_G <- W_diff_otu_G[, !colnames(W_diff_otu_G) %in% drop_cols]
F_diff_otu_G <- F_diff_otu_G[, grepl("NFF|NFA", colnames(F_diff_otu_G)), drop = FALSE]

F_diff_otu_G <- F_diff_otu_G[F_diff$ID[order(F_diff$LDA, decreasing = TRUE)][1:20],]
W_diff_otu_G <- W_diff_otu_G[row.names(F_diff_otu_G),]


#datExpr0 <- read.csv("gene_exp.csv",row.names = 1)
otus1 <- otus[rowSums(otus > 0) >= ceiling(ncol(otus) * 0.1), ]
otus1 <- otus1[,colnames(W_diff_otu_G)]
otus1 <- otus1[rowSums(otus1 > 0) >= ceiling(ncol(otus1) * 0.1), ]
s_rel_NW <- sweep(otus1, 2, colSums(otus1), "/")
# log10 转换
s_log_NW <- log10(s_rel_NW + 1e-6)
datExpr0 <- data.frame(t(s_log_NW))


sampleTree = hclust(dist(datExpr0), method ="average");
par(cex = 0.6)	
par(mar =c(0,4,2,0))	
plot(sampleTree, main ="Sample clustering to detectoutliers",sub="", xlab="", cex.lab = 1.5,
     cex.axis= 1.5, cex.main = 2)
abline(h = 32,col="red"); 
clust = cutreeStatic(sampleTree, cutHeight = 32, minSize = 10)

table(clust)	
keepSamples <- (clust == 1)	
datExpr <- datExpr0[keepSamples, ]		
nGenes <- ncol(datExpr)	
nSamples <- nrow(datExpr)

#traitData <- read.csv("ClinicalTraits.csv")
traitData <- F_diff_otu_G
traitData <- t(traitData)
allTraits <-  traitData 

datTraits <- allTraits	
#rownames(datTraits) <- datTraits$Mice	
#datTraits <- datTraits[rownames(datExpr),]
#datTraits <- datTraits[-1]
#collectGarbage() 
datTraits <- as.data.frame(datTraits)
colnames(datTraits)
names(datTraits)
head(datTraits)
sampleTree2 = hclust(dist(datTraits), method ="average")
traitColors = numbers2colors(datTraits, signed = FALSE);
plotDendroAndColors(sampleTree2,
                    traitColors,
                    groupLabels = names(datTraits),
                    main ="Sample dendrogram and trait heatmap")




powers  <- c(c(1:20), seq(22, 30, 2))
sft = pickSoftThreshold(datExpr, powerVector = powers, verbose = 5)
sizeGrWindow(9,5)	
par(mfrow =c(1,2))	
cex1 = 0.9
plot(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     xlab="SoftThreshold(power)",ylab="ScaleFreeTopologyModelFit,signedR^2",type="n",
     main =paste("Scaleindependence"))
text(sft$fitIndices[,1], -sign(sft$fitIndices[,3])*sft$fitIndices[,2],
     labels = powers, cex = cex1, col = "red")
abline(h = 0.90, col = "red")
data <- data.frame(xlab = sft$fitIndices[,1], ylab = -sign(sft$fitIndices[,3])*sft$fitIndices[,2])
View(data)

plot(sft$fitIndices[,1], sft$fitIndices[,5],
     xlab="SoftThreshold(power)",ylab="MeanConnectivity", type="n",
     main =paste("Meanconnectivity"))
text(sft$fitIndices[,1], sft$fitIndices[,5],labels=powers, cex=cex1,col="red")


net <- blockwiseModules(datExpr,
                        power = 16,	 
                        TOMType ="unsigned", 
                        minModuleSize = 100,	# minModuleSize 
                        reassignThreshold = 0,
                        mergeCutHeight = 0.25,	
                        numericLabels = TRUE,
                        pamRespectsDendro = FALSE,
                        saveTOMs = TRUE,
                        saveTOMFileBase ="femaleMouseTOM",
                        verbose = 3,
                        maxBlockSize = 20000)
table(net$colors)
sizeGrWindow(12, 9)

#mergedColors <- labels2colors(net$colors, colorSeq = myColors)
mergedColors <- labels2colors(net$colors) 
table(mergedColors)
plotDendroAndColors(net$dendrograms[[1]],
                    mergedColors[net$blockGenes[[1]]],
                    "Modulecolors",
                    dendroLabels = FALSE, 
                    hang = 0.03,
                    addGuide = TRUE, 
                    guideHang = 0.05)




dim(MEs)
dim(datTraits)
row.names(MEs)
datTraits_W <- data.frame(t(W_diff_otu_G))

rownames(datTraits_W) <- rownames(net$MEs)


MEs <- orderMEs(net$MEs) 
moduleTraitCor <- cor(MEs, datTraits_W, use = "p") 
moduleTraitPvalue <- corPvalueStudent(moduleTraitCor, nSamples)

pdf(file = 'labeledHeatmap.pdf', width = 12,height = 8)
textMatrix <- paste(signif(moduleTraitCor, 2), "\n(", signif(moduleTraitPvalue, 1), ")", sep = "")
dim(textMatrix) <- dim(moduleTraitCor) 
labeledHeatmap(Matrix = moduleTraitCor, 
               xLabels = names(datTraits_W),
               yLabels = names(MEs), 
               ySymbols = names(MEs),
               colorLabels = FALSE, 
               colors = greenWhiteRed(50), 
               textMatrix = textMatrix, 
               setStdMargins = FALSE, 
               cex.text = 0.7, 
               zlim = c(-1,1), 
               cex.lab.y = 0.6,
               cex.lab.x = 0.7,
               yColorWidth = strheight("M")/2,
               main = paste("Module-trait relationships"))
dev.off()


# ===============================
# ===============================

library(pheatmap)
MEs <- orderMEs(MEs)
ME_cor <- cor(MEs, use = "pairwise.complete.obs", method = "pearson")
nSamples <- nrow(MEs)
ME_p <- corPvalueStudent(ME_cor, nSamples)
#sig_label <- ifelse(ME_p < 0.001, "***",
                    #ifelse(ME_p < 0.01, "**",
                       #    ifelse(ME_p < 0.05, "*", "")))

#display_mat <- matrix(
#  paste0(round(ME_cor, 2), sig_label),
#  nrow = nrow(ME_cor),
#  dimnames = dimnames(ME_cor)
#)
pheatmap(
  ME_cor,
  color = colorRampPalette(c("#2166AC", "white", "#B2182B"))(100),
  breaks = seq(-1, 1, length.out = 101),
  #display_numbers = display_mat,
  number_color = "black",
  fontsize_number = 9,
  cluster_rows = TRUE,
  cluster_cols = TRUE,
  border_color = "grey80",
  main = "Correlation heatmap of module eigengenes",
  width = 8,
  height = 7
)
write.csv(ME_cor, "ME_self_correlation_matrix.csv")
write.csv(ME_p, "ME_self_correlation_pvalue.csv")










