
library(tidyverse)
library(microeco)
library(magrittr)
library(mecodev)
library(writexl)
#install.packages("writexl")
library(tibble)
library(readxl)
otu_tax_combined <- read.csv("../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]

species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
Genus_df <- species_B[, "Genus", drop = FALSE]
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])



otu <- otu[rowSums(otu_no_tax) >= 500, ]
otu <- otu[rowSums(otu > 0) >= ceiling(ncol(otu) * 0.1), ]


tax <- tidy_taxonomy(tax)
tax <- tax[rownames(otu), ]

all(rownames(otu) == rownames(tax))

otu_rel <- sweep(otu, 2, colSums(otu), "/")



data_nf <- microtable$new(otu_table = otu_rel,
                          sample_table = sample,
                          tax_table = tax)
data_nf

data <- clone(data_nf) 
data

l1 <- trans_diff$new(
  dataset = data, 
  method = "lefse", 
  group = "PERIOD", 
  taxa_level = "all", 
  alpha = 0.05, 
  p_adjust_method = "fdr", 
  lefse_subgroup = NULL, 
  #lefse_norm = 1000000, 
  #nresam = 0.6667，
  #boots = 100, #bootstrap
  #lefse_min_subsam = 3 
)
saveRDS(l1, "B_diff_l1_D.rds")
l11 <- readRDS("B_diff_l1_D.rds")
l1$res_diff %>% head()
result <- l1$res_diff

write.csv(result,"D_res_diff.csv",quote = FALSE,row.names = FALSE)

tmp <- clone(l1)
tmp



lda <- tmp$plot_diff_bar(
  threshold = 3.7, 
  color_values = c("#bed2c5","#ffa396"),
  group_order = c("后期","前期"),
  width = 0.5
)
colnames(lda$data)

lda$data <- lda$data[!grepl("norank", lda$data$Taxa, ignore.case = TRUE), ]

lda$data$Value <- abs(lda$data$Value)

lda
lda1 <- lda + 
  scale_y_continuous(limits = c(0,6), expand = c(0,0),breaks = seq(0,6,1))+
  geom_text(aes(label = Significance), color = "black",hjust =-0.3, show.legend = F)+
  theme_classic()+
  theme(axis.text.x =  element_text(size = 13, face = 2),#face 1 2 3 4 5
        axis.text.y =  element_text(size = 10, face = 2),
        axis.title.x = element_text(size = 13, face = 2),
        legend.text =  element_text(size = 13, face = 2),
        legend.title = element_text(size = 13, face = 2))
lda1
ggsave("lda_bar_F.pdf",lda1, width = 5, height = 5, family="serif")

library(tidytree)
library(ggtree)

clad <- l1$plot_diff_cladogram(
  
  use_taxa_num = 300, 
  use_feature_num = 20, 
  clade_label_level = 6, 
  only_select_show = FALSE, 
  color = c("#bed2c5","#ffa396"),
  group_order = c("后期","前期"),
  node_size_offset = 1.5,
  annotation_shape = 21,
  annotation_shape_size = 4.5,
  alpha = 0.1
)
clad

clad1 <- clad+
  theme(legend.text =  element_text(size = 10, face = 2),
        legend.title = element_text(size = 10, face = 2))
clad1
ggsave("cladogram.pdf",clad1, width = 10, height = 6, family="serif")