library(reticulate)
exit
reticulate::py_install(c("matplotlib", "pandas", "networkx"))
reticulate::py_install("seaborn")
globals ().clear () 
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
import networkx as nx

from networkx.readwrite import json_graph
import json #1
from collections import Counter#1
import pandas#1

import copy#1
import random#1
import csv

import seaborn as sns
F_f = nx.read_graphml("F.f_mb_net.graphml")
H_f = nx.read_graphml("H.f_mb_net.graphml")
W_f = nx.read_graphml("W.f_mb_net.graphml")
D_f = nx.read_graphml("D.f_mb_net.graphml")

for net in (F_f, H_f, W_f, D_f):
  print(net.order(), net.size(),
        nx.number_connected_components(net))


W_f = nx.read_graphml("W.f_mb_net.graphml")
node_data = []
for node, attrs in W_f.nodes(data=True):
    row = {"node_id": node}  
    row.update(attrs)       
    node_data.append(row)


df_nodes = pd.DataFrame(node_data)


df_nodes.to_csv("W_f_nodes_with_annotations.csv", index=False, encoding="utf-8")

print(W_f_nodes_with_annotations.csv")
print({len(df_nodes)}")
print("")
print(df_nodes.head())






netdict = {
    "F_f": F_f,
    "H_f": H_f,
    "W_f": W_f,
    "D_f": D_f
}

# fix node name mapping
for net in netdict.keys():
  mapping = {node: data['name'] for node, data in netdict[net].nodes(data=True)}
  nx.relabel_nodes(netdict[net], mapping, copy=False)


def get_connected_graph(net):
  # Get a list of connected components
  components = list(nx.connected_components(net))
  # Find the largest connected component
  largest_component = max(components, key=len)
  # Create a new graph containing only the largest component
  net_largest = net.subgraph(largest_component)
  print('Connected graph:', nx.is_connected(net_largest))
  return(net_largest)


F_f = get_connected_graph(F_f)
H_f = get_connected_graph(H_f)
W_f = get_connected_graph(W_f)
D_f = get_connected_graph(D_f)

# add abundances -------------------------------
# F_f
metadata_F_f  = pd.read_csv("F.f_metadata_metadata.csv")
metadata_F_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)
print(metadata_F_f)
# H_f
metadata_H_f  = pd.read_csv("H.f_metadata_metadata.csv")
metadata_H_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)
print(metadata_H_f)
# W_f
metadata_W_f  = pd.read_csv("W.f_metadata_metadata.csv")
metadata_W_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)
print(metadata_W_f)
# D_f
metadata_D_f  = pd.read_csv("D.f_metadata_metadata.csv")
metadata_D_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)
print(metadata_D_f)
def add_abundance(net, metadata):
  abundance_dict = pd.Series(metadata.Abundance.values, index=metadata.Label).to_dict()
  nx.set_node_attributes(net, abundance_dict, 'Abundance')

add_abundance(F_f, metadata_F_f)
add_abundance(H_f, metadata_H_f)
add_abundance(W_f, metadata_W_f)
add_abundance(D_f, metadata_D_f)

print(metadata_F_f.columns)
# add edge weights -----------------------------------
# MHNO
weights_F_f  = pd.read_csv("edgeweights_F.f.csv")
weights_F_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)

# MHO
weights_H_f  = pd.read_csv("edgeweights_H.f.csv")
weights_H_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)

# MUNO
weights_W_f  = pd.read_csv("edgeweights_W.f.csv")
weights_W_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)

# MUO
weights_D_f  = pd.read_csv("edgeweights_D.f.csv")
weights_D_f.rename(columns=lambda x: x.replace('.', '|'), inplace=True)

def add_weights(net, weights):
  for _, row in weights.iterrows():
      v1, v2, w = row["v1"], row["v2"], row["edgeweight"]
      if net.has_edge(v1, v2):
          net[v1][v2]["weight"] = w
          net[v1][v2]["invWeight"] = 1 - w
      else:
          print(f"edge {v1},{v2} not found")

add_weights(F_f, weights_F_f)
add_weights(H_f, weights_H_f)
add_weights(W_f, weights_W_f)
add_weights(D_f, weights_D_f)

# === Calculate global properties ===
def get_pos_neg_edges(net):
  pos_edges_net, neg_edges_net = [], []
  for edge in net.edges(data = True):
    if edge[-1]['weight'] > 0:
      pos_edges_net.append(edge[-1]['weight'])
    else:
      neg_edges_net.append(edge[-1]['weight'])
  print('% positive edge: {0}\n% negative edges: {1}'.
      format(100 * len(pos_edges_net)/net.size(),
             100 * len(neg_edges_net)/net.size()))

print("######### F_f #########")
get_pos_neg_edges(F_f)
print("######### H_f #########")
get_pos_neg_edges(H_f)
print("######### W_f #########")
get_pos_neg_edges(W_f)
print("######### D_f #########")
get_pos_neg_edges(D_f)

# === Get Local Properties ===
# Degree
def get_basic_properties(net):
  degree_sequence = sorted((d for n, d in net.degree()), reverse=True)
  print('Number of nodes: {0} \nNumber of edges: {1} \nMax degree: {2} \nDensity: {3}'
  .format(net.order(), net.size(), max(degree_sequence), nx.density(net)))

print("F_f #############"); get_basic_properties(F_f)
print("H_f ############"); get_basic_properties(H_f)
print("W_f #############"); get_basic_properties(W_f)
print("D_f ############"); get_basic_properties(D_f)

F_f_names = list(F_f.nodes())
H_f_names = list(H_f.nodes())
W_f_names = list(W_f.nodes())
D_f_names = list(D_f.nodes())

meandegF_f = sum([i[1] for i in F_f.degree])/F_f.order()
meandegH_f = sum([i[1] for i in H_f.degree])/H_f.order()
meandegW_f = sum([i[1] for i in W_f.degree])/W_f.order()
meandegD_f = sum([i[1] for i in D_f.degree])/D_f.order()
print(meandegF_f, meandegH_f, meandegW_f, meandegD_f)


def get_betw(G):
  dc = nx.degree_centrality(G)
  clsness = nx.closeness_centrality(G)
  btwness_G = nx.betweenness_centrality(G, weight="invWeight")

  print('Centrality (mean):', sum(dc.values())/len(dc))
  print('Closeness (mean):', sum(clsness.values())/len(clsness))
  print('Betweenness (mean):', sum(btwness_G.values())/len(btwness_G))
  return(dc, clsness, btwness_G)
##########改动内容#########################
results = {}

print("F_f ###########################")
results["F_f"] = {}
results["F_f"]["centrality"], results["F_f"]["closeness"], results["F_f"]["betweenness"] = get_betw(F_f)

print("H_f ###########################")
results["H_f"] = {}
results["H_f"]["centrality"], results["H_f"]["closeness"], results["H_f"]["betweenness"] = get_betw(H_f)

print("W_f ###########################")
results["W_f"] = {}
results["W_f"]["centrality"], results["W_f"]["closeness"], results["W_f"]["betweenness"] = get_betw(W_f)

print("D_f ###########################")
results["D_f"] = {}
results["D_f"]["centrality"], results["D_f"]["closeness"], results["D_f"]["betweenness"] = get_betw(D_f)
##########改动内容#########################

names = ["F_f", "H_f", "W_f", "D_f"]

for i, net in enumerate([F_f, H_f, W_f, D_f]):
    print('#### ', names[i], '###################')
    
 
    avg_path = nx.average_shortest_path_length(
        net, 
        weight=lambda u, v, d: abs(d["invWeight"]) 
    )
    
    print('Average shortest path length:', avg_path)

netdict = {
    "F_f": F_f,
    "H_f": H_f,
    "W_f": W_f,
    "D_f": D_f
}

all_nodes = set().union(*[G.nodes() for G in netdict.values()])
print("Total number of nodes: ", len(all_nodes))

metrics = {}

for net, G in netdict.items():
    metrics[net] = {
        "degree": dict(G.degree()),
        "betweenness": nx.betweenness_centrality(G, weight = "invWeight"),
        "closeness": nx.closeness_centrality(G)
    }

data = []

for node in all_nodes:
    for net in netdict.keys():
        degree = metrics[net]["degree"].get(node, None)
        betweenness = metrics[net]["betweenness"].get(node, None)
        closeness = metrics[net]["closeness"].get(node, None)

        data.append({
            "nodo": node,
            "red": net,
            "grado": degree,
            "betweenness": betweenness,
            "closeness": closeness
        })

df = pd.DataFrame(data)
df.to_csv("./network_metrics.csv")

shortest_path_lengths = {}

for net, G in netdict.items():
    path_lengths = []
    for nodo_origen, lengths in dict(nx.shortest_path_length(G, weight=lambda u,v,d: abs(d["invWeight"]))).items():
        path_lengths.extend(lengths.values())

    shortest_path_lengths[net] = path_lengths

with open("./shortest_paths.json", "w") as f:
    json.dump(shortest_path_lengths, f)

cores_F = nx.core_number(F_f)
cores_H = nx.core_number(H_f)
cores_W = nx.core_number(W_f)
cores_D = nx.core_number(D_f)

mho_col = "#2a9d8f"
mhno_col = "#264653"
muo_col = "#edafb8"
muno_col = "#703d67"





fig, axes = plt.subplots(1, 4, figsize=(12, 4))


x_min = 0
x_max = 20
x_lim = (x_min, x_max)
xticks = list(range(0, 21, 2))

# ---------------- F_f ----------------
freqs = Counter(cores_F.values())
vals, counts = zip(*sorted(freqs.items(), key=lambda x: x[0]))
axes[0].bar(vals, counts, color=mhno_col)
axes[0].set_title("F_f", fontsize=12, fontweight='bold')
axes[0].set_ylabel("Frequency", fontsize=12)
axes[0].set_xlabel("K-Cores", fontsize=12)
axes[0].set_xticks(xticks)
axes[0].set_xlim(x_lim)
axes[0].tick_params(axis="both", which="major", labelsize=10)

# ---------------- H_f ----------------
freqs = Counter(cores_H.values())
vals, counts = zip(*sorted(freqs.items(), key=lambda x: x[0]))
axes[1].bar(vals, counts, color=mho_col)
axes[1].set_title("H_f", fontsize=12, fontweight='bold')
axes[1].set_xlabel("K-Cores", fontsize=12)
axes[1].set_xticks(xticks)
axes[1].set_xlim(x_lim)
axes[1].tick_params(axis="both", which="major", labelsize=10)

# ---------------- W_f ----------------
freqs = Counter(cores_W.values())
vals, counts = zip(*sorted(freqs.items(), key=lambda x: x[0]))
axes[2].bar(vals, counts, color=muno_col)
axes[2].set_title("W_f", fontsize=12, fontweight='bold')
axes[2].set_xlabel("K-Cores", fontsize=12)
axes[2].set_xticks(xticks)
axes[2].set_xlim(x_lim)
axes[2].tick_params(axis="both", which="major", labelsize=10)

# ---------------- D_f ----------------
freqs = Counter(cores_D.values())
vals, counts = zip(*sorted(freqs.items(), key=lambda x: x[0]))
axes[3].bar(vals, counts, color=muo_col)
axes[3].set_title("D_f", fontsize=12, fontweight='bold')
axes[3].set_xlabel("K-Cores", fontsize=12)
axes[3].set_xticks(xticks)
axes[3].set_xlim(x_lim)
axes[3].tick_params(axis="both", which="major", labelsize=10)

plt.tight_layout()
plt.savefig("./kcores.png", format='png', dpi=1200, bbox_inches='tight')
# ===================== 导出 K-Core =====================
df = pd.DataFrame(list(cores_F.items()), columns=['Node', 'k-core'])
df.to_csv('./F_f_kcores.csv', index=False)

df = pd.DataFrame(list(cores_H.items()), columns=['Node', 'k-core'])
df.to_csv('./H_f_kcores.csv', index=False)

df = pd.DataFrame(list(cores_W.items()), columns=['Node', 'k-core'])
df.to_csv('./W_f_kcores.csv', index=False)

df = pd.DataFrame(list(cores_D.items()), columns=['Node', 'k-core'])
df.to_csv('./D_f_kcores.csv', index=False)




def find_keystone_taxa(G, name_converter=None, network_name=None, quantile_cutoff=0.9):
    #bet = nx.betweenness_centrality(G, weight = "invWeight")
    bet = nx.betweenness_centrality(G, weight=lambda u,v,d: abs(d["invWeight"]))
    deg = dict(G.degree())

    df = pd.DataFrame({
        'OTU': list(bet.keys()),
        'bet': list(bet.values()),
        'deg': [deg[n] for n in bet.keys()]
    })

    if name_converter is not None:
        df = df.merge(name_converter, on='OTU', how='left')

    bet_q = df['bet'].quantile(quantile_cutoff)
    deg_q = df['deg'].quantile(quantile_cutoff)

    df['bottleneck'] = df['bet'] > bet_q
    df['hub'] = df['deg'] > deg_q
    df['keystone'] = df['bottleneck'] & df['hub']

    if network_name is not None:
        df['Network'] = network_name

    return df, bet_q, deg_q


metadata_F_f = pd.read_csv("F.f_metadata_metadata.csv")
metadata_H_f = pd.read_csv("H.f_metadata_metadata.csv")
metadata_W_f = pd.read_csv("W.f_metadata_metadata.csv")
metadata_D_f = pd.read_csv("D.f_metadata_metadata.csv")

df_F, _, _ = find_keystone_taxa(F_f, metadata_F_f.rename(columns={'Label': 'OTU'}), network_name='F_f')
df_H, _, _ = find_keystone_taxa(H_f, metadata_H_f.rename(columns={'Label': 'OTU'}), network_name='H_f')
df_W, _, _ = find_keystone_taxa(W_f, metadata_W_f.rename(columns={'Label': 'OTU'}), network_name='W_f')
df_D, _, _ = find_keystone_taxa(D_f, metadata_D_f.rename(columns={'Label': 'OTU'}), network_name='D_f')

df_all = pd.concat([df_F, df_H, df_W, df_D], ignore_index=True)
df_all.to_csv("./keystoneTaxa.csv", index=False)

print("OVER")
