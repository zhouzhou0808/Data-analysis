library(SpiecEasi)
library(phyloseq)
library(genefilter)
library(igraph)
library(dplyr)
library(ggplot2)
library(patchwork)
library(tidyverse)
library(writexl)
rm(list = ls())
otu_tax_combined <- read.csv("../../OTU_Tax.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))
Genus_df <- species_B[, "Genus", drop = FALSE]
otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
Gro_raw <- read_excel("../../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])



samples_post <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP", ]) 
samples_post_F <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP" & grepl("FA", Gro_raw$TYPE), ]) 
samples_post_H <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP" & grepl("F", Gro_raw$TYPE), ]) 
samples_post_W <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP" & Gro_raw$TYPE == "S", ])
samples_post_D <- row.names(Gro_raw[Gro_raw$PERIOD == "LWP" & Gro_raw$TYPE == "W", ]) 

sample_matrix <- rbind(
  data.frame(ID = samples_pre_F, Group = "POST_F"),
  data.frame(ID = samples_pre_H, Group = "POST_H"),
  data.frame(ID = samples_pre_W, Group = "POST_W"),
  data.frame(ID = samples_pre_D, Group = "POST_D")
)

Group_post <- data.frame(sample_matrix)
otus_post <- otu_no_tax[, Group_post$ID]
Gro_species_B


otu <- otu_table(otus_post, taxa_are_rows = TRUE)
# ----------------------
# ----------------------
sample_df <- sample_data(Group_post)
rownames(sample_df) <- Group_post$ID  
# ----------------------
tax <- tax_table(as.matrix(Gro_species_B))
physeq <- phyloseq(otu, sample_df, tax)
physeq

(physeq.F <- subset_samples(physeq, Group == "POST_F")) 
(physeq.H <- subset_samples(physeq, Group == "POST_H")) 
(physeq.W <- subset_samples(physeq, Group == "POST_W")) 
(physeq.D <- subset_samples(physeq, Group == "POST_D"))



(physeq.F <- filter_taxa(physeq.F,
                           flist =  filterfun(kOverA(k = 10, A = 10)),
                           prune = TRUE)) 
(physeq.H <- filter_taxa(physeq.H,
                            flist =  filterfun(kOverA(k = 10, A = 10)),
                            prune = TRUE)) 
(physeq.W <- filter_taxa(physeq.W,
                           flist =  filterfun(kOverA(k = 5, A =10)),
                           prune = TRUE))
(physeq.D <- filter_taxa(physeq.D,
                            flist =  filterfun(kOverA(k = 5, A = 10)),
                            prune = TRUE))
ZBJ_otus <- read.csv("../../ZBJ_otus_table.csv", row.names = 1, check.names = FALSE)
##############################################################################################################################
pathogen_taxa <- rownames(ZBJ_otus) 

top_taxa_add_pathogen <- function(ps, N = 1000) {
  

  taxa_sums <- taxa_sums(ps)
  topN <- names(sort(taxa_sums, decreasing = TRUE))[1:N]
  
  
  keep <- unique(c(topN, pathogen_taxa))
  

  keep <- keep[keep %in% taxa_names(ps)]
  

  prune_taxa(keep, ps)
}



physeq.F.f <- top_taxa_add_pathogen(physeq.F, 1000)
physeq.H.f <- top_taxa_add_pathogen(physeq.H, 1000)
physeq.W.f <- top_taxa_add_pathogen(physeq.W, 1000)
physeq.D.f <- top_taxa_add_pathogen(physeq.D, 1000)



exportMeta <- function(physeq, filename){
  taxa <- data.frame(physeq@tax_table) %>% rownames_to_column(var = "Label")
  mean_ab <- data.frame(Abundance = apply(data.frame(physeq@otu_table), 1, mean)) %>% rownames_to_column(var = "Label")
  metadata <- left_join(taxa, mean_ab, by = "Label") 
  write_csv(metadata, paste0(filename, "_metadata.csv"), quote = "needed")
}

exportMeta(physeq.F.f, "./F.f_metadata")
exportMeta(physeq.H.f, "./H.f_metadata")
exportMeta(physeq.W.f, "./W.f_metadata")
exportMeta(physeq.D.f, "./D.f_metadata")


##############################################################################################################################

# Build spiecEasi networks -----------------------------------------------------



set.seed(123)

F.f_mb <- spiec.easi(
  physeq.F.f,
  method = "mb",
  nlambda = 30,
  lambda.min.ratio = 1e-2,
  sel.criterion = "stars",
  pulsar.select = TRUE,
  pulsar.params = list(
    rep.num = 100,
    thresh = 0.05,
    ncores = 2
  ),
  verbose = TRUE
)

saveRDS(F.f_mb, "./mb_F.f_net.rds")


ig.F.f.mb <- adj2igraph(getRefit(F.f_mb),  
                         vertex.attr=list(name=taxa_names(physeq.F.f)))

write_graph(ig.F.f.mb, "F.f_mb_net.graphml", format="graphml")
######################################################################

set.seed(123)

H.f_mb <- spiec.easi(
  physeq.H.f,
  method = "mb",
  nlambda = 30,
  lambda.min.ratio = 1e-2,
  sel.criterion = "stars",
  pulsar.select = TRUE,
  pulsar.params = list(
    rep.num = 100,
    thresh = 0.05,
    ncores = 2
  ),
  verbose = TRUE
)

saveRDS(H.f_mb, "./mb_H.f_net.rds")



ig.H.f.mb <- adj2igraph(getRefit(H.f_mb),  
                        vertex.attr=list(name=taxa_names(physeq.H.f)))

write_graph(ig.H.f.mb, "H.f_mb_net.graphml", format="graphml")
######################################################################

set.seed(123)

W.f_mb <- spiec.easi(
  physeq.W.f,
  method = "mb",
  nlambda = 30,
  lambda.min.ratio = 1e-2,
  sel.criterion = "stars",
  pulsar.select = TRUE,
  pulsar.params = list(
    rep.num = 100,
    thresh = 0.05,
    ncores = 2
  ),
  verbose = TRUE
)

saveRDS(W.f_mb, "./mb_W.f_net.rds")



ig.W.f.mb <- adj2igraph(getRefit(W.f_mb),  
                        vertex.attr=list(name=taxa_names(physeq.W.f)))

write_graph(ig.W.f.mb, "W.f_mb_net.graphml", format="graphml")


######################################################################

set.seed(123)

D.f_mb <- spiec.easi(
  physeq.D.f,
  method = "mb",
  nlambda = 30,
  lambda.min.ratio = 1e-2,
  sel.criterion = "stars",
  pulsar.select = TRUE,
  pulsar.params = list(
    rep.num = 100,
    thresh = 0.05,
    ncores = 2
  ),
  verbose = TRUE
)

saveRDS(D.f_mb, "./mb_D.f_net.rds")



ig.D.f.mb <- adj2igraph(getRefit(D.f_mb),  
                        vertex.attr=list(name=taxa_names(physeq.D.f)))

write_graph(ig.D.f.mb, "D.f_mb_net.graphml", format="graphml")
## Edge stability matrices -------------------------------------------------
get_edge_support <- function(se_obj, ig_obj, physeq_obj){
  
  edge_st <- getOptMerge(se_obj)
  rownames(edge_st) <- rownames(otu_table(physeq_obj))
  colnames(edge_st) <- rownames(otu_table(physeq_obj))
  
  se_edgelist <- data.frame(as_edgelist(ig_obj)) %>%
    rename(OTU_1 = X1, OTU_2 = X2)
  edge_stab_df <- as.data.frame(as.matrix(edge_st)) %>% 
    rownames_to_column(var = "OTU_1") %>% 
    reshape2::melt(id.vars = "OTU_1") %>%
    rename(OTU_2 = variable)
  
  edge_support <- se_edgelist %>%
    left_join(edge_stab_df, by = c("OTU_1", "OTU_2"))
  
  return(edge_support)
}

# mb
F.f_support <- get_edge_support(F.f_mb, ig.F.f.mb, physeq.F.f)
H.f_support <- get_edge_support(H.f_mb, ig.H.f.mb, physeq.H.f)
W.f_support <- get_edge_support(W.f_mb, ig.W.f.mb, physeq.W.f)
D.f_support <- get_edge_support(D.f_mb, ig.D.f.mb, physeq.D.f)


supportDF <- bind_rows(F.f_support %>% mutate(Network = "F.f"),
                       H.f_support %>% mutate(Network = "H.f"),
                       W.f_support %>% mutate(Network = "W.f"),
                       D.f_support %>% mutate(Network = "D.f"))
pal <- c("#264653", "#2A9D8F", "#703d57", "#edafb8", "#e6af2e")

edge.p <- supportDF %>%
  ggplot(aes(x = value, fill = Network)) +
  geom_histogram(binwidth = .05) +
  scale_fill_manual(values = pal) +
  theme_bw() +
  facet_wrap(~ Network, scales = "free_y") +
  labs(x = "Edge Bootstrap Support (%)",
       y = "Count")
edge.p  
edge.p

ggsave("./edgeSupport.png",
       edge.p,
       bg = "white",
       height = 8,
       width = 12,
       units = "cm",
       dpi = 800)

## stars curves ----------------------------

png("starsCurves.png",
    width = 1600, height = 1600, res = 300) 

par(mfrow = c(2, 2),    
    mar = c(4, 4, 2, 1)) 

plot(F.f_mb$select, legends = FALSE, main = "F.f")
plot(H.f_mb$select, legends = FALSE, main = "H.f")
plot(W.f_mb$select, legends = FALSE, main = "W.f")
plot(D.f_mb$select, legends = FALSE, main = "D.f")

dev.off()

## Edge weights ------------------------
edgeweights <- function(physeqObj, spiecObj, igraphObj){
  
  weight.mat <- symBeta(getOptBeta(spiecObj), mode = "maxabs")
  colnames(weight.mat) <- taxa_names(physeqObj)
  rownames(weight.mat) <- taxa_names(physeqObj)
  
  edge.list <- ends(igraphObj, E(igraphObj))
  
  edge.weight <- apply(edge.list, 1, function(x){
    weight.mat[x[1], x[2]]
  })
  
  edge.df <- data.frame(
    v1 = edge.list[,1],
    v2 = edge.list[,2],
    edgeweight = edge.weight,
    stringsAsFactors = FALSE
  )
  
  return(edge.df)
}

F.f.ew <- edgeweights(physeq.F.f, F.f_mb, ig.F.f.mb)
H.f.ew <- edgeweights(physeq.H.f, H.f_mb, ig.H.f.mb)
W.f.ew <- edgeweights(physeq.W.f, W.f_mb, ig.W.f.mb)
D.f.ew <- edgeweights(physeq.D.f, D.f_mb, ig.D.f.mb)


write_csv(F.f.ew, "edgeweights_F.f.csv")
write_csv(H.f.ew, "edgeweights_H.f.csv")
write_csv(W.f.ew, "edgeweights_W.f.csv")
write_csv(D.f.ew, "edgeweights_D.f.csv")



keystone.df <- read_csv("keystoneTaxa.csv")
keystone.df$Network <- gsub("_", ".", keystone.df$Network) #

F.f_mb <- readRDS("./mb_F.f_net.rds")
ig.F.f.mb <- read_graph("F.f_mb_net.graphml", format = "graphml")

H.f_mb <- readRDS("./mb_H.f_net.rds")
ig.H.f.mb <- read_graph("H.f_mb_net.graphml", format = "graphml")

W.f_mb <- readRDS("./mb_W.f_net.rds")
ig.W.f.mb <- read_graph("W.f_mb_net.graphml", format = "graphml")

D.f_mb <- readRDS("./mb_D.f_net.rds")
ig.D.f.mb <- read_graph("D.f_mb_net.graphml", format = "graphml")



all.phyla <- unique(c(
  # all samples
  data.frame(tax_table(physeq.F.f))$Phylum,
  data.frame(tax_table(physeq.H.f))$Phylum,
  data.frame(tax_table(physeq.W.f))$Phylum,
  data.frame(tax_table(physeq.D.f))$Phylum
  
))

# build color palette 

okabe_ito <- c(
  "#8DD3C7",
  "#FFFFB3",
  "#BEBADA",
  "#FB8072",
  "#80B1D3",
  "#FDB462",
  "#B3DE69",
  "#FCCD95",
  "#999999"
)

pal <- colorRampPalette(okabe_ito)(length(all.phyla))


pal.df <- data.frame(cbind(pal, all.phyla))
colnames(pal.df) <- c("Color", "Phylum")
pal.df


## Helper function -----------------
plotNetwork <- function(physeqObj, igraphObj, spiecObj, keystoneDF, netName,
                        seed = 42){
  # color matching
  col.df <- data.frame(V(igraphObj)) %>%
    rownames_to_column(var = "OTU") %>%
    left_join(data.frame(tax_table(physeqObj)) %>%
                rownames_to_column(var = "OTU"),
              by = "OTU") %>%
    left_join(pal.df, by = "Phylum")
  
  # abundances
  ab.df <- if (max(otu_table(physeqObj)) > 1) {
    apply(data.frame(otu_table(physeqObj))/ 100, 1, mean) 
  } else {
    apply(data.frame(otu_table(physeqObj)), 1, mean)
  }
  
  # edge weights
  weight.mat <- symBeta(getOptBeta(spiecObj))
  colnames(weight.mat) <- taxa_names(physeqObj)
  rownames(weight.mat) <- taxa_names(physeqObj)
  
  edge.weights <- sapply(E(igraphObj), function(e) {
    v1 <- ends(igraphObj, e)[1]
    v2 <- ends(igraphObj, e)[2]
    weight.mat[v1, v2]
  })
  
  # keystone taxa
  key.taxa <- keystoneDF %>%
    filter(Network == netName, keystone == TRUE) %>%
    pull(OTU)
  
  (is.keystone <- V(igraphObj)$name %in% key.taxa)
  
  
  vertex.frame.color <- ifelse(is.keystone, "black", "gray20")
  vertex.frame.width <- ifelse(is.keystone, 4, 1)
  
  # adjust transparency
  node.color <- adjustcolor(col.df$Color, alpha.f = 0.6)
  node.color[is.keystone] <- adjustcolor(col.df$Color[is.keystone], alpha.f = 1)
  
  
  # plot network
  set.seed(seed)
  am.coord <- layout_with_fr(igraphObj)
  
  plot(igraphObj, layout=am.coord, 
       vertex.label=NA,
       vertex.color = node.color,
       vertex.size = abs(log(ab.df)),
       vertex.frame.color = vertex.frame.color,
       vertex.frame.width = vertex.frame.width,
       
       edge.color = adjustcolor(ifelse(edge.weights > 0,
                                       "gray20", # + associations
                                       "#E41A1C"  # - associations
       ) , 
       alpha.f = 0.6),
       edge.width = 2
  )
  
}

# Export networks ------------------
exportNetworkPNG <- function(physeqObj, igraphObj, spiecObj, keystoneDF, netName,
                             filename, width = 3000, height = 3000, res = 300, seed = 42) {
  
  png(filename,
      width = width, height = height, res = res, units = "px")
  par(omi=c(0,0,0,0), mgp=c(0,0,0),mar=c(0,0,0,0))
  
  plotNetwork(physeqObj, igraphObj, spiecObj, keystoneDF, netName, seed = seed)
  
  dev.off()
}

# 【仅替换这里的对象名为你的文件】
exportNetworkPNG(physeq.F.f, ig.F.f.mb, F.f_mb, keystone.df, "F.f", "F.f.png")
exportNetworkPNG(physeq.H.f, ig.H.f.mb, H.f_mb, keystone.df, "H.f", "H.f.png")
exportNetworkPNG(physeq.W.f, ig.W.f.mb, W.f_mb, keystone.df, "W.f", "W.f.png")
exportNetworkPNG(physeq.D.f, ig.D.f.mb, D.f_mb, keystone.df, "D.f", "D.f.png")





get_top10_phyla <- function(physeq_obj){
  
  phylum_abund <- tax_glom(physeq_obj, taxrank = "Phylum")
  
  
  phylum_rel <- transform_sample_counts(phylum_abund, function(x) x / sum(x))
  

  otu <- otu_table(phylum_rel)
  
  
  if(!taxa_are_rows(phylum_rel)){
    otu <- t(otu)
  }
  
 
  mean_abund <- rowMeans(as.matrix(otu))
  

  tax <- tax_table(phylum_rel)
  

  df <- data.frame(
    Phylum = tax[, "Phylum"],
    MeanAbundance = mean_abund
  )
  

  df <- df %>%
    group_by(Phylum) %>%
    summarise(MeanAbundance = sum(MeanAbundance)) %>%
    arrange(desc(MeanAbundance))
  

  top10 <- head(df, 10)
  
  return(top10)
}


top10_F <- get_top10_phyla(physeq.F.f)
top10_H <- get_top10_phyla(physeq.H.f)
top10_W <- get_top10_phyla(physeq.W.f)
top10_D <- get_top10_phyla(physeq.D.f)


top10_F
top10_H
top10_W
top10_D

top10_all <- rbind(
  cbind(Group = "F", top10_F),
  cbind(Group = "H", top10_H),
  cbind(Group = "W", top10_W),
  cbind(Group = "D", top10_D)
)

write.csv(top10_all,
          "Top10_phyla.csv",
          row.names = FALSE)


