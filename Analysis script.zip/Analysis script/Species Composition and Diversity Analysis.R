#library(reticulate)
#repl_python()  #进入python
library(tidyr)
library(dplyr)
library(readxl)
library(ggplot2)
library(ggsci)
library(patchwork) 
library(writexl)
library(tibble)
t###########################################Species Composition and Abundance Analysis############################

#group <- read.csv("Group1.csv")
#species <- read_excel("Taxonomy.reads.xlsx", sheet = "Sheet1")
otu_tax_combined <- read.csv("../OTU_Tax_合并表格.csv", row.names = 1, check.names = FALSE)
species_B=otu_tax_combined[otu_tax_combined$Kingdom0=="Bacteria",]
species_B <- species_B[-nrow(species_B), ]
colnames(species_B )
Gro_species_B <- species_B[,(ncol(species_B)-5):ncol(species_B)]
species_B <- species_B %>%
  select(-any_of(c("PM10-1","PM10-2","PM10-3","PM5-4","PM5-5","PM5-6")))

phylum_df <- species_B[, "Phylum", drop = FALSE]

otu_no_tax <- species_B[, 1:(ncol(species_B)-8)]
rotu_no_tax <- as.data.frame(
  apply(otu_no_tax, 2, function(x) x / sum(x))
)
colnames(otu_no_tax)

row_means <- rowMeans(rotu_no_tax, na.rm = TRUE)
colnames(rotu_no_tax_with_mean)
rotu_no_tax_with_mean <- cbind(mean = row_means, rotu_no_tax)
mean_rfinal_data <- cbind(rotu_no_tax_with_mean, phylum_df)
mean_phylum <- mean_rfinal_data[, c("mean", "Phylum")]
View(
  mean_rfinal_data %>%
    group_by(Phylum) %>%
    summarise(total_mean = sum(mean, na.rm = TRUE)) %>%
    arrange(desc(total_mean)) %>%
    slice_head(n = 3)
)
#######################################
Gro_raw <- read_excel("../Taxonomy.reads.xlsx", sheet = 2) %>%
  column_to_rownames(var = colnames(.)[1])
Gro_raw_Q <- Gro_raw %>% filter(PERIOD == "EWP")
Gro_raw_H <- Gro_raw %>% filter(PERIOD == "LWP")

final_data <- cbind(otu_no_tax, phylum_df)
rfinal_data <- cbind(rotu_no_tax, phylum_df)

phylum_df <- final_data[, "Phylum", drop = FALSE]

write.csv(
  final_data,
  "species_abundance_table.csv",
  row.names = TRUE
)
write.csv(
  rfinal_data,
  "rspecies_abundance_table.csv",
  row.names = TRUE
)
species_abundance_table <- read.csv(
  "species_abundance_table.csv",
  row.names = 1,
  check.names = FALSE
)
colnames(species_abundance_table)

###根据行名提取对应列
Gro_raw_H$TYPE <- factor(
  Gro_raw_H$TYPE,
  levels = c(
    "FA_A",
    "FA_F",
    "F_A",
    "F_F",
    "S",
    "W"
  )
)

Gro_raw_H <- Gro_raw_H[order(Gro_raw_H$TYPE), ]

final_data_H <- final_data[, rownames(Gro_raw_H)]
final_data_Q <- final_data[, rownames(Gro_raw_Q)]
length(final_data_H)
length(final_data_Q)
colnames(final_data_H)
colnames(final_data_Q)


long_df <- final_data %>%
  pivot_longer(-Phylum, names_to = "SA_ID", values_to = "Abundance") %>%
  left_join(Gro_raw_Q[, c("SA_ID","TYPE")], by = "SA_ID")


top10_phylum_Q <- long_df %>%
  group_by(TYPE, Phylum) %>%
  summarise(total = sum(Abundance, na.rm = TRUE), .groups = "drop") %>%
  group_by(TYPE) %>%
  slice_max(total, n = 10)


View(top10_phylum_Q)



long_df <- final_data %>%
  pivot_longer(-Phylum, names_to = "SA_ID", values_to = "Abundance") %>%
  left_join(Gro_raw_H[, c("SA_ID","TYPE")], by = "SA_ID")


top10_phylum_H <- long_df %>%
  group_by(TYPE, Phylum) %>%
  summarise(total = sum(Abundance, na.rm = TRUE), .groups = "drop") %>%
  group_by(TYPE) %>%
  slice_max(total, n = 10)

View(top10_phylum_H)


phylum_Q  <- cbind(final_data_Q, phylum_df)
colnames(phylum_Q)
rownames(Gro_raw_Q)
phylum_H  <- cbind(final_data_H, phylum_df)

phylum_Q <- phylum_Q %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum), .groups = "drop")
phylum_H <- phylum_H %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum), .groups = "drop")


phylum_Q <- phylum_Q %>%
  mutate(total = rowSums(across(2:ncol(.)))) %>%
  arrange(desc(total)) %>%
  select(-total)
phylum_H <- phylum_H %>%
  mutate(total = rowSums(across(2:ncol(.)))) %>%
  arrange(desc(total)) %>%
  select(-total)

top7_Q <- unique(phylum_Q$Phylum)[1:10]
top7_H <- unique(phylum_H$Phylum)[1:10]

top7_Q <- top7_Q[top7_Q != " p__norank"]
top7_H <- top7_H[top7_H != " p__norank"]
top7_Q
top7_H

phylum_Q$Phylum <- ifelse(phylum_Q$Phylum %in% top7_Q, phylum_Q$Phylum, " Other")
phylum_H$Phylum <- ifelse(phylum_H$Phylum %in% top7_H, phylum_H$Phylum, " Other")

phylum_Q<- phylum_Q %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum), .groups = "drop")
length(phylum_Q)
phylum_Q[, tail(seq_len(ncol(phylum_Q)), 5)]
phylum_H<- phylum_H %>%
  group_by(Phylum) %>%
  summarise(across(everything(), sum), .groups = "drop")

phylum_Q <- phylum_Q %>%
  mutate(across(-Phylum, ~ .x / sum(.x)))
phylum_H <- phylum_H %>%
  mutate(across(-Phylum, ~ .x / sum(.x)))

colnames(phylum_Q)[-1] <- as.character(seq_len(ncol(phylum_Q) - 1))
colnames(phylum_H)[-1] <- as.character(seq_len(ncol(phylum_H) - 1))

df_phylum_Q <- phylum_Q %>%
  pivot_longer(-Phylum, names_to = "sample", values_to = "abundance")
df_phylum_Q$sample <- as.numeric(df_phylum_Q$sample)
phylum_Q$Phylum

df_phylum_H <- phylum_H %>%
  pivot_longer(-Phylum, names_to = "sample", values_to = "abundance")
df_phylum_H$sample <- as.numeric(df_phylum_H$sample)
phylum_H$Phylum

my_order <- c(" p__Acidobacteriota"," p__Actinomycetota"," p__Bacillota"              
              ," p__Bacteroidota"," p__Cyanobacteriota"," p__Myxococcota"            
              ," p__Planctomycetota", " p__Pseudomonadota", " p__Thermodesulfobacteriota"
              ," Other")

df_phylum_H$Phylum <- factor(df_phylum_H$Phylum, levels = my_order)

df_phylum_Q$Phylum <- factor(df_phylum_Q$Phylum, levels = my_order)


###############
p1_H <-   ggplot(df_phylum_H, aes(x = sample, y = abundance, fill = Phylum)) +
  geom_area() +
  annotate("rect", xmin = min(df_phylum_H$sample), 
           xmax = max(df_phylum_H$sample),, ymin = 0, ymax = 1, 
           color = "black", fill = NA, linewidth = 0.5) +
  scale_fill_manual(values = c(" p__Acidobacteriota" = "#CBD7FD",
                               " p__Actinomycetota" = "#FDCABF",
                               " p__Bacillota" = "#CBDDDB",
                               " p__Bacteroidota" = "#E0BBD0",
                               " p__Cyanobacteriota" = "#EFC99B",
                               " p__Myxococcota" = "#C7E1A6",
                               " p__Planctomycetota" = "#D3E1F3",
                               " p__Pseudomonadota" ="#FFDEBC",
                               " p__Thermodesulfobacteriota" = "#EBB3BE",
                               " Other" = "#CCCACB"))  +
  theme_minimal() +
  labs(x = "", y = "Phylum", fill = "Phylum") +
  theme(axis.ticks = element_blank(),
        panel.grid = element_blank(),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.title.y = element_text(margin = margin(r = 0),
                                    size = 14,      
                                    face = "bold"),
        panel.border = element_blank()
  )
p1_Q <-   ggplot(df_phylum_Q, aes(x = sample, y = abundance, fill = Phylum)) +
  geom_area() +
  annotate("rect", xmin = min(df_phylum_H$sample), 
           xmax = max(df_phylum_H$sample),, ymin = 0, ymax = 1, 
           color = "black", fill = NA, linewidth = 0.5) +
  scale_fill_manual(values = c(" p__Acidobacteriota" = "#CBD7FD",
                               " p__Actinomycetota" = "#FDCABF",
                               " p__Bacillota" = "#CBDDDB",
                               " p__Bacteroidota" = "#E0BBD0",
                               " p__Cyanobacteriota" = "#EFC99B",
                               " p__Myxococcota" = "#C7E1A6",
                               " p__Planctomycetota" = "#D3E1F3",
                               " p__Pseudomonadota" ="#FFDEBC",
                               " p__Thermodesulfobacteriota" = "#EBB3BE",
                               " Other" = "#CCCACB")) +
  theme_minimal() +
  labs(x = "", y = "Phylum", fill = "Phylum") +
  theme(axis.ticks = element_blank(),
        panel.grid = element_blank(),
        axis.text.x = element_blank(),
        axis.text.y = element_blank(),
        axis.title.y = element_text(margin = margin(r = 0),
                                    size = 14,      
                                    face = "bold"),
        panel.border = element_blank()
  )
p1_Q+p1_H
p1_H
##############################
Gro_raw_Q_Q <- Gro_raw_Q %>%
  mutate(ID = row_number())  
df_phylum_Q <- df_phylum_Q %>%
  left_join(Gro_raw_Q_Q, by = c("sample" = "ID")) 
table(Gro_raw_Q_Q$TYPE)

# '#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B'

Treatments_colors <- c('FA_A' = "#FDCABF", 'FA_F' = "#EFC99B", 'F_A' ="#CBDDDB",'F_F' ="#bed2c5", 'S' = "#CBD7FD",'W' = "#E0BBD0")

p2_Q <- ggplot(Gro_raw_Q_Q, aes(x = ID, y = 0.5, fill = TYPE)) +
  geom_tile(width = 1, height = 0.2) +  
  scale_fill_manual(values = Treatments_colors, name = "Treatments") +
  theme(
    panel.grid = element_blank(),
    panel.background = element_blank(),
    axis.ticks.x = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    legend.text = element_text(color = 'black', size = 9),
    legend.title = element_text(color = 'black', size = 10),
    plot.margin = margin(t = 2, b = 2, unit = "mm")
  ) +
  scale_x_continuous(
    breaks = unique(Gro_raw_Q_Q$ID),
    labels = unique(Gro_raw_Q_Q$ID),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  scale_y_continuous(expand = expansion(mult = c(0, 0))) +
  labs(x = NULL, y = NULL)

p2_Q
p1_Q <- p1_Q + 
  theme(
    axis.ticks.x = element_blank(),
    axis.text.x = element_blank()
  )


p3_Q <- p2_Q / p1_Q + 
  plot_layout(heights = c(0.1, 4), guides =  "collect")&
  theme(legend.position = "bottom")


p3_Q

#########################################
Gro_raw_H_H <- Gro_raw_H %>%
  mutate(ID = row_number())  
df_phylum_H <- df_phylum_H %>%
  left_join(Gro_raw_H_H, by = c("sample" = "ID"))  
table(Gro_raw_Q_Q$TYPE)

# '#9FCBE2', '#2D83BE', '#B3E08B', '#2FA128', '#FFE69A', '#FF8000', '#E41316', '#D22FF6', '#6A3A9B'

Treatments_colors <- c('FA_A' = "#FDCABF", 'FA_F' = "#EFC99B", 'F_A' ="#CBDDDB",'F_F' ="#bed2c5", 'S' = "#CBD7FD",'W' = "#E0BBD0")
p2_H <- ggplot(Gro_raw_H_H, aes(x = ID, y = 0.5, fill = TYPE)) +
  geom_tile(width = 1, height = 0.2) +  
  scale_fill_manual(values = Treatments_colors, name = "Treatments") +
  theme(
    panel.grid = element_blank(),
    panel.background = element_blank(),
    axis.ticks.x = element_blank(),
    axis.ticks.y = element_blank(),
    axis.text.x = element_blank(),
    axis.text.y = element_blank(),
    legend.text = element_text(color = 'black', size = 9),
    legend.title = element_text(color = 'black', size = 10),
    plot.margin = margin(t = 2, b = 2, unit = "mm")
  ) +
  scale_x_continuous(
    breaks = unique(Gro_raw_H_H$ID),
    labels = unique(Gro_raw_H_H$ID),
    expand = expansion(mult = c(0.05, 0.05))
  ) +
  scale_y_continuous(expand = expansion(mult = c(0, 0))) +
  labs(x = NULL, y = NULL)

p2_H
p1_H <- p1_H + 
  theme(
    axis.ticks.x = element_blank(),
    axis.text.x = element_blank()
  )


p3_H <- p2_H / p1_H + 
  plot_layout(heights = c(0.1, 4), guides =  "collect")&
  theme(legend.position = "bottom")

p3_Q
p3_H
p3_H+p3_Q
ggsave("areaplot.png",p3, height = 4, width = 12, dpi = 1200)
ggsave("areaplot.tif",p3, height = 4, width = 12, dpi = 1200)
ggsave("areaplot.pdf",p3, height = 4, width = 12, dpi = 1200)
#################################################################
##################################################################


###########################################α/β Diversity Analysis############################

rm(list = ls())
library(vegan) 
library(ggpubr)
library(patchwork)
####################################
#comun = read.csv("species_abundance_table.csv",header=T,row.names=1)
#comun <- final_data %>%
  select(-Phylum)
comun <- otu_no_tax[rowSums(otu_no_tax > 0) >= 2, ]
comun <- comun[rowSums(comun) >= 10, ]
#comun <- comun[apply(comun, 1, max, na.rm = TRUE) >= 1000, ]
colnames(comun)
otu <- as.data.frame(comun)  
#rownames(otu) <- otu[, 1] 
otu <- t(otu)
alpha_index <- function(x, base = exp(1)) {   
  observed_species <- estimateR(x)[1,]
  richness <- rowSums(x > 0)	
  chao1 <- estimateR(x)[2, ]	#Chao1 
  ace <- estimateR(x)[4, ]	#ACE 
  shannon <- diversity(x, index = 'shannon', base = base)	#Shannon 
  simpson <- diversity(x, index = 'simpson')	#Gini-Simpson 
  pielou <- diversity(x, index = 'shannon', base = base) / log(estimateR(x)[1, ], base)	#Pielou 
  goods_covers <- 1 - rowSums(x == 1) / rowSums(x)	#goods_coverage
  result <- data.frame(observed_species, richness, chao1, ace, shannon, simpson, pielou, goods_covers)
}
alpha <- alpha_index(otu)
Gro_raw$group <- paste(Gro_raw$TYPE, Gro_raw$PERIOD, sep = "_")
alpha$group <- Gro_raw[rownames(alpha), "group"]
write.csv(alpha, "alpha_index.csv",row.names = T )
colnames(alpha)

alpha_F <- alpha[grep("FA", alpha$group), ]
# 羽毛
alpha_H <- alpha[grep("F", alpha$group), ]
# 水
alpha_W <- alpha[grep("W", alpha$group), ]
# 底泥
alpha_D <- alpha[grep("S", alpha$group), ]
wilcox.test(chao1 ~ PERIOD, data = alpha_D)
# 2. Shannon 
wilcox.test(shannon ~ PERIOD, data = alpha_D)
# 3. Simpson 
wilcox.test(simpson ~ PERIOD, data = alpha_D)
alpha_D %>%
  group_by(PERIOD) %>%
  summarise(
    SA_NUM = n(),
    chao1_AV = mean(chao1, na.rm = T),
    shannon_AV = mean(shannon, na.rm = T),
    simpson_AV = mean(simpson, na.rm = T)
  )
#alpha$PERIOD <- factor(alpha$PERIOD, levels = c("EWP", "LWP"))

##########



alpha <- alpha %>%
  mutate(
    PERIOD = ifelse(grepl("EWP", group, ignore.case = FALSE), "EWP", "LWP")
  )

# 1（ Chao1 ）
box_stat <- alpha_D %>%
  group_by(PERIOD) %>%
  summarise(
    ymin = boxplot.stats(chao1)$stats[1],
    lower = boxplot.stats(chao1)$stats[2],
    middle = boxplot.stats(chao1)$stats[3],
    upper = boxplot.stats(chao1)$stats[4],
    ymax = boxplot.stats(chao1)$stats[5],
    .groups = "drop"
  )
# 2. 
g <- ggplot(alpha_D, aes(x = PERIOD, y = chao1)) +

  geom_boxplot(
    fill = NA,
    color = "black",
    width = 0.6,
    outlier.shape = NA,
    coef = 0,
    whisker.linewidth = 0,
    staplewidth = 0
  ) +
    geom_segment(
    data = box_stat,
    aes(x = PERIOD, xend = PERIOD, y = upper, yend = ymax),
    linetype = "dashed", linewidth = 0.5
  ) +
  geom_segment(
    data = box_stat,
    aes(x = PERIOD, xend = PERIOD, y = lower, yend = ymin),
    linetype = "dashed", linewidth = 0.5
  ) +
  geom_segment(
    data = box_stat,
    aes(x = as.numeric(factor(PERIOD)) - 0.1,
        xend = as.numeric(factor(PERIOD)) + 0.1,
        y = ymax, yend = ymax),
    linewidth = 0.6
  ) +
   geom_segment(
    data = box_stat,
    aes(x = as.numeric(factor(PERIOD)) - 0.1,
        xend = as.numeric(factor(PERIOD)) + 0.1,
        y = ymin, yend = ymin),
    linewidth = 0.6
  ) +
  geom_jitter(
    aes(color = PERIOD),
    width = 0.18, shape = 16, size = 1.5, alpha = 0.9
  ) +
 
  scale_color_manual(values = c("EWP" = "#ffa396", "LWP" = "#bed2c5")) +
   stat_compare_means(
    method = "t.test",
    label = "p.signif",
    hide.ns = TRUE,
    size = 6, vjust = 0.8
  ) +
   labs(x = "", y = "chao1") +
  theme_bw() +
  theme(
    panel.grid = element_blank(),
    legend.position = "none",
    axis.text = element_text(size = 12, color = "black"),
    axis.title = element_text(size = 13, face = "bold")
  )+
    coord_cartesian(ylim = c(14000, 17000))

g
ggsave("chao1_D.pdf", plot = g, width = 4, height = 6, dpi = 600)


#########################β-PCOA################################

#asv <- read.delim("otus.txt", row.names = 1, sep = '\t', header = T)
#group1 <- read.delim("group.txt",row.names = 1 , sep = '\t' , header = T)
library(tibble)

colour_2 <- c("#ADC299",
              "#ffa396",
             
              "#D59EBE",
              "#EFC99B",
              "#AABCDB",
              "#ADC299",
              "#CBD7FD",
              "#E0BBD0",
              "#FDCABF",
              "#CBDDDB",
              "#D3E1F3",
              "#FFDEBC",
              "#EBB3BE",
              "#AABCDB",
              "#98D6D5",
              "#bed2c5"
              )


#set.seed(006)
#asv_rari <- as.data.frame(t(rrarefy(t(asv),min(colSums(asv))))) %>% # rrarefy() 
#filter(.,rowSums(.)>0)
#colSums(asv_rari)
comun = read.csv("species_abundance_table.csv",header=T,row.names=1)
comun <- final_data %>%
  select(-Phylum)
comun <- otu_no_tax[rowSums(otu_no_tax > 0) >= 2, ]
comun <- comun[rowSums(comun) >= 10, ]
asv_rari <- comun[
  rowSums(comun > 0) >= ncol(comun)*0.01,
]
asv_rari <- decostand(asv_rari, method = "total")
#asv_rari <- comun[apply(comun, 1, max, na.rm = TRUE) >= 2000, ]
asv_rari <- t(asv_rari)
asv_rari <- as.data.frame(asv_rari)

asv_rari <- asv_rari[rowSums(asv_rari) > 0, ]
asv_rari_D <- asv_rari[rownames(asv_rari) %in% sample_D, ]
asv_rari_post <- asv_rari[rownames(asv_rari) %in% , ]

sample_F <- rownames(Gro_raw)[grepl("FA", Gro_raw$group)]
sample_H <- rownames(Gro_raw)[grepl("F", Gro_raw$group)]
sample_W <- rownames(Gro_raw)[grepl("W", Gro_raw$group)]
sample_D <- rownames(Gro_raw)[grepl("S", Gro_raw$group)]


bray_curtis_distance <- vegdist(
  asv_rari_D,
  method = "bray"
)
head(as.matrix(bray_curtis_distance))



group <- alpha %>%  
  rownames_to_column(.,var = 'sample_name')
group <- group[, c("sample_name", "group","PERIOD")]
#group <- group[group$PERIOD=="LWP",]
bac_data <- asv_rari_D %>%
  as.data.frame() %>%
  rownames_to_column(var = 'sample_name') %>%
  left_join(.,group,by = 'sample_name')
tail(colnames(bac_data))

PERMANOVA_bac <- adonis2(bray_curtis_distance ~ PERIOD , 
                         data = bac_data , permutations = 9999)
PERMANOVA_bac


##> PCoA
PCoA <- cmdscale (bray_curtis_distance,eig=TRUE)

PCoA12 <- PCoA$points[,1:2]

pcoa <- round(PCoA$eig/sum(PCoA$eig)*100,digits=2)


PCoA_bac <- as.data.frame(PCoA12) %>% 
  rownames_to_column(var = 'sample_name') %>%
  left_join(.,group,by='sample_name')
PCoA_bac


PCoA.1 <- ggplot(data=PCoA_bac, aes(x = V1, y = V2, fill=PERIOD,color=PERIOD))+
  geom_point(size=3)+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("PCoA1 (",pcoa[1],"%)"),
       y=paste0("PCoA2 (",pcoa[2],"%)"))+ 
  scale_color_manual(values = colour_2) +
  scale_fill_manual(values = colour_2)+
  theme_bw(base_size = 15)+
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(size = 16,color="black"),
    axis.text.y = element_text(size = 16,color="black"),
    axis.title.y = element_text(size = 18,color="black"),
    axis.title.x = element_text(size = 18,color="black"),
    axis.ticks.length = unit(0.2, "cm"),
    legend.position = 'none',
    # legend.position=c(0.001,0.999),
    legend.title = element_blank(),
    legend.key=element_blank(),
    legend.text = element_text(color="black",size=9,face = "bold"),
    legend.spacing.x=unit(0.1,'cm'),
    legend.key.width=unit(0.5,'cm'),
    legend.key.height=unit(0.6,'cm'),
    legend.background=element_blank(),
    legend.box.background=element_rect(colour="black"),
    legend.justification=c(0.0001,1)
  )
PCoA.1
table(PCoA_bac$PERIOD)

PCoA.2 <- ggplot(data=PCoA_bac, aes(x = V1, y = V2, fill=PERIOD,color=PERIOD))+
  geom_point(size=2)+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("PCoA1 (",pcoa[1],"%)"),
       y=paste0("PCoA2 (",pcoa[2],"%)"))+ 
  scale_color_manual(values = colour_2) +
  scale_fill_manual(values = colour_2)+
  theme_bw(base_size = 15)+
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(size = 16,color="black"),
    axis.text.y = element_text(size = 16,color="black"),
    axis.title.y = element_text(size = 18,color="black"),
    axis.title.x = element_text(size = 18,color="black"),
    axis.ticks.length = unit(0.2, "cm"),
    #legend.position = 'none',
    legend.position=c(0.001,0.999),
    legend.title = element_blank(),
    legend.key=element_blank(),
    legend.text = element_text(color="black",size=9,face = "bold"),
    legend.spacing.x=unit(0.1,'cm'),
    legend.key.width=unit(0.5,'cm'),
    legend.key.height=unit(0.6,'cm'),
    legend.background=element_blank(),
    legend.box.background=element_rect(colour="black"),
    legend.justification=c(0.0001,1)
  )+
  stat_ellipse(data=PCoA_bac,
               geom = "polygon",level=0.95,
               linetype = 2,linewidth=1,
               aes(fill=PERIOD),
               alpha=0.2,
               show.legend = F,
               type = "norm")+
  coord_cartesian(
    xlim = c(-0.5, 0.5),
    ylim = c(-0.7, 0.7))
PCoA.2

PCoA.3 <- ggplot(data=PCoA_bac, aes(x = V1, y = V2, fill=PERIOD,color=PERIOD))+
  geom_point(size=5)+
  geom_vline(xintercept = 0,lty="dashed")+
  geom_hline(yintercept = 0,lty="dashed")+
  labs(x=paste0("PCoA1 (",pcoa[1],"%)"),
       y=paste0("PCoA2 (",pcoa[2],"%)"))+ 
  scale_color_manual(values = colour_2) +
  scale_fill_manual(values = colour_2)+
  theme_bw(base_size = 15)+
  theme(
    panel.grid.major = element_blank(), 
    panel.grid.minor = element_blank(),
    axis.text.x = element_text(size = 16,color="black"),
    axis.text.y = element_text(size = 16,color="black"),
    axis.title.y = element_text(size = 18,color="black"),
    axis.title.x = element_text(size = 18,color="black"),
    axis.ticks.length = unit(0.2, "cm"),
    legend.position = 'none',
    # legend.position=c(0.001,0.999),
    legend.title = element_blank(),
    legend.key=element_blank(),
    legend.text = element_text(color="black",size=9,face = "bold"),
    legend.spacing.x=unit(0.1,'cm'),
    legend.key.width=unit(0.5,'cm'),
    legend.key.height=unit(0.6,'cm'),
    legend.background=element_blank(),
    legend.box.background=element_rect(colour="black"),
    legend.justification=c(0.0001,1)
  )+
  geom_polygon(aes(x = V1, y = V2, fill = PERIOD, group = PERIOD, color = PERIOD),alpha = 0.1, linetype = "longdash", linewidth = 1.5 ,show.legend =  FALSE)
PCoA.3

library(patchwork)

adonis_text <- sprintf("PERMANOVA:\ndf = %d\nR² = %.5f\np-value = %s",
                       PERMANOVA_bac$Df[1], PERMANOVA_bac$R2[1],
                       format.pval(PERMANOVA_bac$`Pr(>F)`[1], digits = 5, eps = 0.00001))


PCoA.4.T <- ggplot() +
  geom_text(aes(x = 0, y = 0.1, label = adonis_text), size = 3.5, color = "black", fontface = "bold") +
  theme_bw() +
  theme(axis.title = element_blank(), axis.ticks = element_blank(), axis.text = element_blank(),
        panel.grid = element_blank(), plot.title = element_blank(), panel.background = element_rect(fill = "white", colour = "black"))
PCoA.4.T

PCoA.4.2 <- ggplot(PCoA_bac, aes(PERIOD, V1, fill = PERIOD)) +
  geom_boxplot(outlier.shape = NA, width = 0.5, color = "black", linetype = 1) +
  scale_fill_manual(values = colour_2)+
  labs(x = NULL,y = NULL)+
  theme_bw()+
  theme(
    legend.position = "none",
    panel.grid = element_blank(),
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    axis.title = element_blank(),
  )+
  theme(aspect.ratio = 1/4)+
  coord_flip()  
PCoA.4.2


PCoA.4.3 <- ggplot(PCoA_bac, aes(PERIOD, V2, fill = PERIOD)) +
  geom_boxplot(outlier.shape = NA, width = 0.5, color = "black", linetype = 1) +
  scale_fill_manual(values = colour_2)+
  theme_bw()+
  theme(
    legend.position = "none",
    panel.grid = element_blank(),
    axis.line = element_blank(),
    axis.ticks = element_blank(),
    axis.text = element_blank(),
    axis.title = element_blank(),
  )
PCoA.4.3

final_plot.1 <- PCoA.4.2 + PCoA.4.T + (PCoA.2 + theme(aspect.ratio = 1)) + PCoA.4.3 + 
  plot_layout(heights = c(1, 4), widths = c(6, 1), ncol = 2, nrow = 2)  

print(final_plot.1)

###########################################
final_plot.2 <- PCoA.4.2 + PCoA.4.T + (PCoA.3 + theme(aspect.ratio = 1)) + PCoA.4.3 + 
  plot_layout(heights = c(1, 4), widths = c(6, 1), ncol = 2, nrow = 2)  

print(final_plot.2)


ggsave(plot = PCoA.1,filename = "P.1.png",width = 200,height = 200,dpi = 600,units = 'mm')
ggsave(plot = PCoA.2,filename = "P.2.png",width = 200,height = 200,dpi = 600,units = 'mm')
ggsave(plot = PCoA.3,filename = "P.3.png",width = 200,height = 200,dpi = 600,units = 'mm')
ggsave(plot = final_plot.1,filename = "P.4.png",width = 200,height = 200,dpi = 600,units = 'mm')
ggsave(plot = final_plot.2,filename = "P.5.png",width = 200,height = 200,dpi = 600,units = 'mm')