
library(vegan)


library(vegan)


otu <- N_otu_post 
ZBJ_otus <- read.csv("../ZBJ_otus_table.csv", row.names = 1, check.names = FALSE)
common_otus <- intersect(colnames(otu), rownames(ZBJ_otus))


otu1 <- otu[, common_otus, drop=FALSE]
p <- sweep(otu1, 2, colSums(otu1), "/")
species_B <- 1 / colSums(p^2)

Comm_ni_wi <- apply(otu1, 1, function(x){
  weighted.mean(species_B, x, na.rm = TRUE)
})
Comm_ni_wi 
Comm_df <- as.data.frame(Comm_ni_wi)
########################################################α多样性（shannon）alpha 

Shannon <- diversity(otu, index = "shannon", MARGIN = 1, base = exp(1))
Simpson <- diversity(otu, index = "simpson", MARGIN = 1, base = exp(1))

alpha <- cbind(样本名 = rownames(otu), Shannon, Simpson)

alpha <- as.data.frame(alpha)
########################################################Avd_df

otu_mat <- as.matrix(t(otu))

otu_mat2 <- otu_mat[apply(otu_mat, 1, sd) != 0, ]

ai <- abs(otu_mat2 - rowMeans(otu_mat2)) / apply(otu_mat2, 1, sd)

avd <- colMeans(ai)
Avd_df <- as.data.frame(avd)
########################################################env_T_TDS/env_ADE/env_H
env_data <- read_excel("../GLMM.xlsx",sheet="LWP")


geo_dist <- dist(cbind(env_data$Lo, env_data$La))
library(vegan)
pcnm_res <- pcnm(geo_dist)
spatial_var <- data.frame(pcnm_res$vectors)
rownames(spatial_var) <- rownames(env_data)



rownames(env_data) <- env_data$ID

env_data$ID <- NULL
env_data$REGION <- NULL
#library(car)

vif(lm( paste(colnames(env_data)[1], "~ ."), data=env_data ))
env_data$Lo <- NULL
env_data$La <- NULL
env_data$G <- NULL
env_data$ORP <- NULL
env_data$EC <- NULL
env_data$B <- NULL
env_data$F <- NULL
env_data$PH <- NULL
env_data$C <- NULL
sample_id <- rownames(otu)
# 1. T + TDS
env_T_TDS <- data.frame(env_data[, c("T", "TDS")])
rownames(env_T_TDS) <- sample_id
# 2. A + D + E
env_ADE <- data.frame(env_data[, c("A", "D", "E")])
rownames(env_ADE) <- sample_id
# 3. H
env_H <- data.frame(env_data[, "H", drop = FALSE])
rownames(env_H) <- sample_id
########################################################F_INT 
WVSF_F <- read.csv(
  file = "../FVSW_suorce.csv",
  row.names = 1,      
  check.names = FALSE,  
  encoding = "UTF-8" 
)

WVSF_F  

F_mean <- data.frame(mean = rowMeans(WVSF_F , na.rm = TRUE))
rownames(F_mean) <- rownames(final_data)
########################################################PCA1_df
dist <- vegdist(otu,method = "bray")
pcoa <- pcoa(dist, correction = "none", rn = NULL)
PC1 = pcoa$vectors[,1]
PC1_df <- data.frame(PC1 = PC1)      
rownames(PC1_df) <- rownames(otu)    
##################PLS-PM
df <- cbind(Avd_df,alpha,env_T_TDS,env_ADE,env_H,F_mean ,Comm_df,PC1_df)
df$SA_ID <- NULL
df <- as.data.frame(df)
df[] <- lapply(df, function(x) as.numeric(as.character(x)))
dat <- scale(df)
dat_blocks <- list(
  F_int   = "mean"        ,
  Env_TT  = c("T","TDS")  ,
  Avd = "avd"             ,
  Shannon = "Shannon"     ,
  C_widch = "Comm_ni_wi"  ,
  C_str = "PC1"  
)
dat_blocks

F_int   = c(0	,0	,0	,0	,0	,0) 
Env_TT  = c(1	,0	,0	,0	,0	,0)
Avd     = c(1	,1	,0	,0	,0	,0)
Shannon = c(1	,1	,0	,0	,0	,0)
C_widch = c(1	,1	,1	,1	,0	,0)
C_str   = c(1	,1	,1	,1	,0	,0) 


dat_path <- rbind(F_int  , 
                  Env_TT ,
                  Avd    ,
                  Shannon,
                  C_widch,
                  C_str  )
colnames(dat_path) <- rownames(dat_path)
dat_path
dat_modes <- rep("A",6)
dat_modes
dat_pls <- plspm(dat,dat_path,dat_blocks,modes=dat_modes)

dat_pls
summary(dat_pls)

########################################################################################################

library(vegan)
library(vegan)
########################################################Comm_df

otu <- N_otu_pre
ZBJ_otus <- read.csv("../ZBJ_otus_table.csv", row.names = 1, check.names = FALSE)
common_otus <- intersect(colnames(otu), rownames(ZBJ_otus))

otu1 <- otu[, common_otus, drop=FALSE]
p <- sweep(otu1, 2, colSums(otu1), "/")
species_B <- 1 / colSums(p^2)

Comm_ni_wi <- apply(otu1, 1, function(x){
  weighted.mean(species_B, x, na.rm = TRUE)
})
Comm_ni_wi ########################################################α（shannon）alpha 

Shannon <- diversity(otu, index = "shannon", MARGIN = 1, base = exp(1))
Simpson <- diversity(otu, index = "simpson", MARGIN = 1, base = exp(1))

alpha <- cbind(SA_ID = rownames(otu), Shannon, Simpson)

alpha <- as.data.frame(alpha)
########################################################Avd_df

otu_mat <- as.matrix(t(otu))

otu_mat2 <- otu_mat[apply(otu_mat, 1, sd) != 0, ]

ai <- abs(otu_mat2 - rowMeans(otu_mat2)) / apply(otu_mat2, 1, sd)

avd <- colMeans(ai)
Avd_df <- as.data.frame(avd)
########################################################env_T_TDS/env_ADE/env_H
env_data <- read_excel("../GLMM.xlsx",sheet="EWP")


geo_dist <- dist(cbind(env_data$Lo, env_data$La))
library(vegan)
pcnm_res <- pcnm(geo_dist)
spatial_var <- data.frame(pcnm_res$vectors)
rownames(spatial_var) <- rownames(env_data)

rownames(env_data) <- env_data$ID

env_data$ID <- NULL
env_data$REGION <- NULL


vif(lm( paste(colnames(env_data)[1], "~ ."), data=env_data ))
env_data$Lo <- NULL
env_data$La <- NULL
env_data$G <- NULL
env_data$ORP <- NULL
env_data$EC <- NULL
env_data$B <- NULL
env_data$F <- NULL
env_data$PH <- NULL
env_data$C <- NULL
sample_id <- rownames(otu)
# 1. T + TDS
env_T_TDS <- data.frame(env_data[, c("T", "TDS")])
rownames(env_T_TDS) <- sample_id
# 2. A + D + E
env_ADE <- data.frame(env_data[, c("A", "D", "E")])
rownames(env_ADE) <- sample_id
# 3. H
env_H <- data.frame(env_data[, "H", drop = FALSE])
rownames(env_H) <- sample_id
########################################################F_INT
WVSF_F <- read.csv(
  file = "../WVSFB_suorce.csv",
  row.names = 1,       
  check.names = FALSE,  
  encoding = "UTF-8"  
)

WVSF_F  
WVSF_F <- WVSF_F[-nrow(WVSF_F), ]
F_mean <- data.frame(mean = rowMeans(WVSF_F , na.rm = TRUE))
rownames(F_mean) <- rownames(final_data)
########################################################PCA1_df
dist <- vegdist(otu,method = "bray")
pcoa <- pcoa(dist, correction = "none", rn = NULL)
PC1 = pcoa$vectors[,1]
PC1_df <- data.frame(PC1 = PC1)      
rownames(PC1_df) <- rownames(otu)     
##################PLS-PM
df <- cbind(Avd_df,alpha,env_T_TDS,env_ADE,env_H,F_mean ,Comm_df,PC1_df)
df$SA_ID <- NULL
df <- as.data.frame(df)
df[] <- lapply(df, function(x) as.numeric(as.character(x)))
dat <- scale(df)
dat_blocks <- list(
  F_int   = "mean"        ,
  Env_TT  = c("T","TDS")  ,
  Avd = "avd"             ,
  Shannon = "Shannon"     ,
  C_widch = "Comm_ni_wi"  ,
  C_str = "PC1"  
)
dat_blocks

F_int   = c(0	,0	,0	,0	,0	,0) 
Env_TT  = c(1	,0	,0	,0	,0	,0)
Avd     = c(1	,1	,0	,0	,0	,0)
Shannon = c(1	,1	,0	,0	,0	,0)
C_widch = c(1	,1	,1	,1	,0	,0)
C_str   = c(1	,1	,1	,1	,0	,0) 


dat_path <- rbind(F_int  , 
                  Env_TT ,
                  Avd    ,
                  Shannon,
                  C_widch,
                  C_str  )
colnames(dat_path) <- rownames(dat_path)
dat_path
dat_modes <- rep("A",6)
dat_modes
dat_pls <- plspm(dat,dat_path,dat_blocks,modes=dat_modes)

dat_pls
summary(dat_pls)
